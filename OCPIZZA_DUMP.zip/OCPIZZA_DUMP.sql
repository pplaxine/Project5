--
-- PostgreSQL database dump
--

-- Dumped from database version 10.5
-- Dumped by pg_dump version 10.5

-- Started on 2018-09-03 20:02:45

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'WIN1252';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 1 (class 3079 OID 12924)
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- TOC entry 3025 (class 0 OID 0)
-- Dependencies: 1
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 213 (class 1259 OID 41317)
-- Name: adresse_compte_utilisateur; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.adresse_compte_utilisateur (
    id integer NOT NULL,
    numero integer,
    rue character varying(50) NOT NULL,
    ville character varying(50) NOT NULL,
    code_postal integer NOT NULL
);


ALTER TABLE public.adresse_compte_utilisateur OWNER TO postgres;

--
-- TOC entry 212 (class 1259 OID 41315)
-- Name: adresse_compte_utilisateur_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.adresse_compte_utilisateur_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.adresse_compte_utilisateur_id_seq OWNER TO postgres;

--
-- TOC entry 3026 (class 0 OID 0)
-- Dependencies: 212
-- Name: adresse_compte_utilisateur_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.adresse_compte_utilisateur_id_seq OWNED BY public.adresse_compte_utilisateur.id;


--
-- TOC entry 211 (class 1259 OID 41309)
-- Name: adresse_livraison; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.adresse_livraison (
    id integer NOT NULL,
    numero integer,
    rue character varying(50) NOT NULL,
    ville character varying(50) NOT NULL,
    code_postal integer NOT NULL
);


ALTER TABLE public.adresse_livraison OWNER TO postgres;

--
-- TOC entry 210 (class 1259 OID 41307)
-- Name: adresse_livraison_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.adresse_livraison_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.adresse_livraison_id_seq OWNER TO postgres;

--
-- TOC entry 3027 (class 0 OID 0)
-- Dependencies: 210
-- Name: adresse_livraison_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.adresse_livraison_id_seq OWNED BY public.adresse_livraison.id;


--
-- TOC entry 203 (class 1259 OID 41277)
-- Name: adresse_restaurant; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.adresse_restaurant (
    id integer NOT NULL,
    numero integer,
    rue character varying(50) NOT NULL,
    ville character varying(50) NOT NULL,
    code_postal integer NOT NULL
);


ALTER TABLE public.adresse_restaurant OWNER TO postgres;

--
-- TOC entry 202 (class 1259 OID 41275)
-- Name: adresse_restaurant_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.adresse_restaurant_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.adresse_restaurant_id_seq OWNER TO postgres;

--
-- TOC entry 3028 (class 0 OID 0)
-- Dependencies: 202
-- Name: adresse_restaurant_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.adresse_restaurant_id_seq OWNED BY public.adresse_restaurant.id;


--
-- TOC entry 223 (class 1259 OID 41362)
-- Name: boisson; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.boisson (
    produit_id integer NOT NULL,
    taille integer NOT NULL
);


ALTER TABLE public.boisson OWNER TO postgres;

--
-- TOC entry 230 (class 1259 OID 41390)
-- Name: commande; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.commande (
    id integer NOT NULL,
    reference_commande character varying(20) NOT NULL,
    date_creation timestamp without time zone NOT NULL,
    compte_utilisateur_id integer,
    coordonnees_livraison_id integer NOT NULL,
    regle boolean NOT NULL,
    mode_reglement integer NOT NULL,
    etat_commande integer NOT NULL,
    restaurant_id integer NOT NULL,
    hotesse_id integer,
    livreur_id integer
);


ALTER TABLE public.commande OWNER TO postgres;

--
-- TOC entry 229 (class 1259 OID 41388)
-- Name: commande_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.commande_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.commande_id_seq OWNER TO postgres;

--
-- TOC entry 3029 (class 0 OID 0)
-- Dependencies: 229
-- Name: commande_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.commande_id_seq OWNED BY public.commande.id;


--
-- TOC entry 215 (class 1259 OID 41325)
-- Name: compte_personnel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.compte_personnel (
    id integer NOT NULL,
    identifiant character varying(20) NOT NULL,
    mot_de_passe character varying(20) NOT NULL,
    prenom character varying(30) NOT NULL,
    nom character varying(30) NOT NULL,
    role integer NOT NULL,
    permission_acces integer NOT NULL
);


ALTER TABLE public.compte_personnel OWNER TO postgres;

--
-- TOC entry 214 (class 1259 OID 41323)
-- Name: compte_personnel_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.compte_personnel_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.compte_personnel_id_seq OWNER TO postgres;

--
-- TOC entry 3030 (class 0 OID 0)
-- Dependencies: 214
-- Name: compte_personnel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.compte_personnel_id_seq OWNED BY public.compte_personnel.id;


--
-- TOC entry 228 (class 1259 OID 41382)
-- Name: compte_utilisateur; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.compte_utilisateur (
    id integer NOT NULL,
    identifiant character varying(20) NOT NULL,
    mot_de_passe character varying(20) NOT NULL,
    prenom character varying(30) NOT NULL,
    nom character varying(30) NOT NULL,
    adresse_compte_utilisateur_id integer NOT NULL,
    numero_telephone numeric(20,0) NOT NULL,
    adresse_email character varying(30) NOT NULL
);


ALTER TABLE public.compte_utilisateur OWNER TO postgres;

--
-- TOC entry 227 (class 1259 OID 41380)
-- Name: compte_utilisateur_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.compte_utilisateur_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.compte_utilisateur_id_seq OWNER TO postgres;

--
-- TOC entry 3031 (class 0 OID 0)
-- Dependencies: 227
-- Name: compte_utilisateur_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.compte_utilisateur_id_seq OWNED BY public.compte_utilisateur.id;


--
-- TOC entry 226 (class 1259 OID 41374)
-- Name: coordonnees_livraison; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.coordonnees_livraison (
    id integer NOT NULL,
    nom character varying(30) NOT NULL,
    prenom character varying(30) NOT NULL,
    adresse_livraison_id integer NOT NULL,
    numero_telephone numeric(20,0) NOT NULL,
    adresse_email character varying(30) NOT NULL
);


ALTER TABLE public.coordonnees_livraison OWNER TO postgres;

--
-- TOC entry 225 (class 1259 OID 41372)
-- Name: coordonnees_livraison_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.coordonnees_livraison_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.coordonnees_livraison_id_seq OWNER TO postgres;

--
-- TOC entry 3032 (class 0 OID 0)
-- Dependencies: 225
-- Name: coordonnees_livraison_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.coordonnees_livraison_id_seq OWNED BY public.coordonnees_livraison.id;


--
-- TOC entry 201 (class 1259 OID 41269)
-- Name: etat_commande; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.etat_commande (
    id integer NOT NULL,
    etat character varying(30) NOT NULL
);


ALTER TABLE public.etat_commande OWNER TO postgres;

--
-- TOC entry 200 (class 1259 OID 41267)
-- Name: etat_commande_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.etat_commande_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.etat_commande_id_seq OWNER TO postgres;

--
-- TOC entry 3033 (class 0 OID 0)
-- Dependencies: 200
-- Name: etat_commande_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.etat_commande_id_seq OWNED BY public.etat_commande.id;


--
-- TOC entry 217 (class 1259 OID 41333)
-- Name: ingredient; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ingredient (
    id integer NOT NULL,
    reference character varying(20) NOT NULL,
    nom character varying(30) NOT NULL
);


ALTER TABLE public.ingredient OWNER TO postgres;

--
-- TOC entry 216 (class 1259 OID 41331)
-- Name: ingredient_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ingredient_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ingredient_id_seq OWNER TO postgres;

--
-- TOC entry 3034 (class 0 OID 0)
-- Dependencies: 216
-- Name: ingredient_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ingredient_id_seq OWNED BY public.ingredient.id;


--
-- TOC entry 220 (class 1259 OID 41346)
-- Name: menu; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.menu (
    produit_id integer NOT NULL,
    reference character varying(20) NOT NULL,
    nom character varying(50) NOT NULL,
    description character varying(500),
    prix numeric(10,2),
    cree_par integer NOT NULL,
    disponible boolean NOT NULL,
    date_creation timestamp without time zone NOT NULL
);


ALTER TABLE public.menu OWNER TO postgres;

--
-- TOC entry 219 (class 1259 OID 41344)
-- Name: menu_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.menu_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.menu_id_seq OWNER TO postgres;

--
-- TOC entry 3035 (class 0 OID 0)
-- Dependencies: 219
-- Name: menu_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.menu_id_seq OWNED BY public.menu.produit_id;


--
-- TOC entry 207 (class 1259 OID 41293)
-- Name: mode_reglement; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mode_reglement (
    id integer NOT NULL,
    type character varying(30) NOT NULL
);


ALTER TABLE public.mode_reglement OWNER TO postgres;

--
-- TOC entry 206 (class 1259 OID 41291)
-- Name: mode_reglement_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.mode_reglement_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.mode_reglement_id_seq OWNER TO postgres;

--
-- TOC entry 3036 (class 0 OID 0)
-- Dependencies: 206
-- Name: mode_reglement_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.mode_reglement_id_seq OWNED BY public.mode_reglement.id;


--
-- TOC entry 231 (class 1259 OID 41396)
-- Name: panier; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.panier (
    id_commande integer NOT NULL,
    produit_id integer NOT NULL,
    quantite integer NOT NULL
);


ALTER TABLE public.panier OWNER TO postgres;

--
-- TOC entry 221 (class 1259 OID 41352)
-- Name: pizza; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pizza (
    produit_id integer NOT NULL,
    taille integer NOT NULL
);


ALTER TABLE public.pizza OWNER TO postgres;

--
-- TOC entry 222 (class 1259 OID 41357)
-- Name: recette; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recette (
    id_ingredient integer NOT NULL,
    pizza_id integer NOT NULL,
    quantite integer NOT NULL
);


ALTER TABLE public.recette OWNER TO postgres;

--
-- TOC entry 209 (class 1259 OID 41301)
-- Name: restaurant; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.restaurant (
    id integer NOT NULL,
    nom character varying(30) NOT NULL,
    adresse_restaurant_id integer NOT NULL
);


ALTER TABLE public.restaurant OWNER TO postgres;

--
-- TOC entry 208 (class 1259 OID 41299)
-- Name: restaurant_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.restaurant_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.restaurant_id_seq OWNER TO postgres;

--
-- TOC entry 3037 (class 0 OID 0)
-- Dependencies: 208
-- Name: restaurant_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.restaurant_id_seq OWNED BY public.restaurant.id;


--
-- TOC entry 205 (class 1259 OID 41285)
-- Name: role; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.role (
    id integer NOT NULL,
    type character varying(30) NOT NULL
);


ALTER TABLE public.role OWNER TO postgres;

--
-- TOC entry 204 (class 1259 OID 41283)
-- Name: role_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.role_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.role_id_seq OWNER TO postgres;

--
-- TOC entry 3038 (class 0 OID 0)
-- Dependencies: 204
-- Name: role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.role_id_seq OWNED BY public.role.id;


--
-- TOC entry 224 (class 1259 OID 41367)
-- Name: stock_bar; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stock_bar (
    id_restaurant integer NOT NULL,
    boisson_id integer NOT NULL,
    quantite integer
);


ALTER TABLE public.stock_bar OWNER TO postgres;

--
-- TOC entry 218 (class 1259 OID 41339)
-- Name: stock_cuisine; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stock_cuisine (
    id_ingredient integer NOT NULL,
    id_restaurant integer NOT NULL,
    quantite integer
);


ALTER TABLE public.stock_cuisine OWNER TO postgres;

--
-- TOC entry 199 (class 1259 OID 41258)
-- Name: taille_boisson; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.taille_boisson (
    id integer NOT NULL,
    taille character varying NOT NULL
);


ALTER TABLE public.taille_boisson OWNER TO postgres;

--
-- TOC entry 198 (class 1259 OID 41256)
-- Name: taille_boisson_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.taille_boisson_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.taille_boisson_id_seq OWNER TO postgres;

--
-- TOC entry 3039 (class 0 OID 0)
-- Dependencies: 198
-- Name: taille_boisson_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.taille_boisson_id_seq OWNED BY public.taille_boisson.id;


--
-- TOC entry 197 (class 1259 OID 41247)
-- Name: taille_pizza; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.taille_pizza (
    id integer NOT NULL,
    taille character varying NOT NULL
);


ALTER TABLE public.taille_pizza OWNER TO postgres;

--
-- TOC entry 196 (class 1259 OID 41245)
-- Name: taille_pizza_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.taille_pizza_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.taille_pizza_id_seq OWNER TO postgres;

--
-- TOC entry 3040 (class 0 OID 0)
-- Dependencies: 196
-- Name: taille_pizza_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.taille_pizza_id_seq OWNED BY public.taille_pizza.id;


--
-- TOC entry 2788 (class 2604 OID 41320)
-- Name: adresse_compte_utilisateur id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adresse_compte_utilisateur ALTER COLUMN id SET DEFAULT nextval('public.adresse_compte_utilisateur_id_seq'::regclass);


--
-- TOC entry 2787 (class 2604 OID 41312)
-- Name: adresse_livraison id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adresse_livraison ALTER COLUMN id SET DEFAULT nextval('public.adresse_livraison_id_seq'::regclass);


--
-- TOC entry 2783 (class 2604 OID 41280)
-- Name: adresse_restaurant id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adresse_restaurant ALTER COLUMN id SET DEFAULT nextval('public.adresse_restaurant_id_seq'::regclass);


--
-- TOC entry 2794 (class 2604 OID 41393)
-- Name: commande id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.commande ALTER COLUMN id SET DEFAULT nextval('public.commande_id_seq'::regclass);


--
-- TOC entry 2789 (class 2604 OID 41328)
-- Name: compte_personnel id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compte_personnel ALTER COLUMN id SET DEFAULT nextval('public.compte_personnel_id_seq'::regclass);


--
-- TOC entry 2793 (class 2604 OID 41385)
-- Name: compte_utilisateur id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compte_utilisateur ALTER COLUMN id SET DEFAULT nextval('public.compte_utilisateur_id_seq'::regclass);


--
-- TOC entry 2792 (class 2604 OID 41377)
-- Name: coordonnees_livraison id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coordonnees_livraison ALTER COLUMN id SET DEFAULT nextval('public.coordonnees_livraison_id_seq'::regclass);


--
-- TOC entry 2782 (class 2604 OID 41272)
-- Name: etat_commande id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.etat_commande ALTER COLUMN id SET DEFAULT nextval('public.etat_commande_id_seq'::regclass);


--
-- TOC entry 2790 (class 2604 OID 41336)
-- Name: ingredient id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ingredient ALTER COLUMN id SET DEFAULT nextval('public.ingredient_id_seq'::regclass);


--
-- TOC entry 2791 (class 2604 OID 41349)
-- Name: menu produit_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu ALTER COLUMN produit_id SET DEFAULT nextval('public.menu_id_seq'::regclass);


--
-- TOC entry 2785 (class 2604 OID 41296)
-- Name: mode_reglement id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mode_reglement ALTER COLUMN id SET DEFAULT nextval('public.mode_reglement_id_seq'::regclass);


--
-- TOC entry 2786 (class 2604 OID 41304)
-- Name: restaurant id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.restaurant ALTER COLUMN id SET DEFAULT nextval('public.restaurant_id_seq'::regclass);


--
-- TOC entry 2784 (class 2604 OID 41288)
-- Name: role id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role ALTER COLUMN id SET DEFAULT nextval('public.role_id_seq'::regclass);


--
-- TOC entry 2781 (class 2604 OID 41261)
-- Name: taille_boisson id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.taille_boisson ALTER COLUMN id SET DEFAULT nextval('public.taille_boisson_id_seq'::regclass);


--
-- TOC entry 2780 (class 2604 OID 41250)
-- Name: taille_pizza id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.taille_pizza ALTER COLUMN id SET DEFAULT nextval('public.taille_pizza_id_seq'::regclass);


--
-- TOC entry 2999 (class 0 OID 41317)
-- Dependencies: 213
-- Data for Name: adresse_compte_utilisateur; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.adresse_compte_utilisateur (id, numero, rue, ville, code_postal) FROM stdin;
1	55	avenue Philippe-Auguste	Paris	75011
2	22	avenue de Saint-Mand�	Paris	75012
3	35	rue des Meuniers	Paris	75012
4	12	rue Breguet	Paris	75011
5	47	rue Volta	Paris	75003
6	44	rue de Bretagne	Paris	75003
7	2	rue de la Roquette	Paris	75011
8	12	rue de la Chine	Paris	75020
9	18	rue Boyer	Paris	75020
10	5	rue Duranti	Paris	75011
\.


--
-- TOC entry 2997 (class 0 OID 41309)
-- Dependencies: 211
-- Data for Name: adresse_livraison; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.adresse_livraison (id, numero, rue, ville, code_postal) FROM stdin;
1	48	rue du Saint-Bernard	Paris	75011
2	55	avenue Philippe-Auguste	Paris	75011
3	22	avenue de Saint-Mand�	Paris	75012
4	66	rue P�tion	Paris	75011
5	35	rue des Meuniers	Paris	75012
6	12	rue Breguet	Paris	75011
7	47	rue Volta	Paris	75003
8	44	rue de Bretagne	Paris	75003
9	2	rue de la Roquette	Paris	75011
10	12	rue de la Chine	Paris	75020
11	18	rue Boyer	Paris	75020
12	73	rue Emilio Castelar	Paris	75011
13	5	rue Duranti	Paris	75011
\.


--
-- TOC entry 2989 (class 0 OID 41277)
-- Dependencies: 203
-- Data for Name: adresse_restaurant; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.adresse_restaurant (id, numero, rue, ville, code_postal) FROM stdin;
1	12	Place de la Bastille	Paris	75011
2	292	bld Voltaire	Paris	75011
3	32	rue Baron le Roy	Paris	75012
4	2	rue L�on Jouhaux	Paris	75010
5	19	Place Gambetta	Paris	75020
\.


--
-- TOC entry 3009 (class 0 OID 41362)
-- Dependencies: 223
-- Data for Name: boisson; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.boisson (produit_id, taille) FROM stdin;
37	3
38	4
39	3
40	4
41	2
42	3
43	4
44	2
45	3
46	4
47	2
48	3
49	4
50	1
51	2
52	3
\.


--
-- TOC entry 3016 (class 0 OID 41390)
-- Dependencies: 230
-- Data for Name: commande; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.commande (id, reference_commande, date_creation, compte_utilisateur_id, coordonnees_livraison_id, regle, mode_reglement, etat_commande, restaurant_id, hotesse_id, livreur_id) FROM stdin;
1	a23cde78	2018-08-27 11:45:42	\N	1	t	3	5	1	3	\N
2	a2cedz45	2018-08-27 11:56:42	\N	4	t	2	6	5	7	\N
3	a23dze25	2018-08-27 12:45:42	\N	12	f	1	5	4	2	\N
4	a23cdf47	2018-08-28 21:21:42	1	1	t	5	5	1	\N	8
5	a23cdda4	2018-08-28 22:25:17	2	4	f	5	4	3	\N	11
6	a23cvzv4	2018-08-28 22:23:52	3	2	t	1	5	4	\N	9
7	a23cde47	2018-08-28 20:16:23	4	2	f	4	6	5	\N	10
8	a2cezc02	2018-08-28 18:21:44	5	5	t	3	4	2	\N	10
9	a2cvrz07	2018-08-28 21:14:26	6	2	t	3	2	2	\N	11
10	a23cvzv2	2018-08-28 19:59:42	7	1	f	2	6	1	\N	11
11	a23vz240	2018-08-28 19:46:30	8	2	f	2	2	4	\N	9
12	a23cez45	2018-08-28 21:56:03	9	2	t	1	1	3	\N	8
13	a23fea24	2018-08-28 21:04:17	10	3	f	4	4	5	\N	9
\.


--
-- TOC entry 3001 (class 0 OID 41325)
-- Dependencies: 215
-- Data for Name: compte_personnel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.compte_personnel (id, identifiant, mot_de_passe, prenom, nom, role, permission_acces) FROM stdin;
1	1234	mdp01	Alfred	Mario	3	99
2	1235	mdp02	Luna	Ninas	3	99
3	2341	mdp03	Vanessa	Souipa	1	34
4	2342	mdp04	Harry	Covert	1	34
5	2343	mdp05	Cyril	Ananas	1	34
6	2344	mdp06	Kiwi	West	1	34
7	2345	mdp07	Miley	Cerise	1	34
8	2431	mdp08	Manu	Papayet	2	6
9	2332	mdp09	Carla	Brugnon	2	6
10	2333	mdp10	Lionel	Litchi	2	6
11	2334	mdp11	Chantal	Goyave	2	6
\.


--
-- TOC entry 3014 (class 0 OID 41382)
-- Dependencies: 228
-- Data for Name: compte_utilisateur; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.compte_utilisateur (id, identifiant, mot_de_passe, prenom, nom, adresse_compte_utilisateur_id, numero_telephone, adresse_email) FROM stdin;
1	g.mansoif	mdp01	G�rard	Mansoif	1	612322521	g.mansoif@gmail.com
2	c.heloire	mdp02	Carmen	H�loire	2	612356345	carmen.he@free.com
3	p.igone	mdp03	Paul	Igone	3	615326548	paul.igone@trade.fr
4	s.lakrep	mdp04	Suzette	Lakrep	4	614263524	s.lkrp@gmail.com
5	t.jamain	mdp05	Th�o	Jasmain	5	656325468	teoj@kousmi.com
6	f.oposte	mdp06	Fidel	Oposte	6	636325452	fideloposte@orange.fr
7	d.hinault	mdp07	Dom	Hinault	7	622365699	domino@gmail.com
8	d.Scott	mdp08	Debie	Scott	8	675652555	dbst@rsdk.com
9	e.hochet	mdp09	Eric	Hochet	9	678565254	e.hochet@hotmail.com
10	m.Angraive	mdp10	M�lusine	Angraive	10	632321414	m.angraive@fvbn.com
\.


--
-- TOC entry 3012 (class 0 OID 41374)
-- Dependencies: 226
-- Data for Name: coordonnees_livraison; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.coordonnees_livraison (id, nom, prenom, adresse_livraison_id, numero_telephone, adresse_email) FROM stdin;
1	Paul	Dubois	1	6325232	p.dubois@gmail.com
2	G�rard	Mansoif	2	612322521	g.mansoif@gmail.com
3	Carmen	H�loire	3	612356345	carmen.he@free.com
4	Louis	Branchant	4	612322521	l.branchant@gmail.com
5	Paul	Igone	5	615326548	paul.igone@trade.fr
6	Suzette	Lakrep	6	614263524	s.lkrp@gmail.com
7	Th�o	Jasmain	7	656325468	teoj@kousmi.com
8	Fidel	Oposte	8	636325452	fideloposte@orange.fr
9	Dom	Hinault	9	622365699	domino@gmail.com
10	Debie	Scott	10	675652555	dbst@rsdk.com
11	Eric	Hochet	11	678565254	e.hochet@hotmail.com
12	Fabien	Tault	12	612146325	f.tault@jihd.com
13	M�lusine	Angraive	13	632321414	m.angraive@fvbn.com
\.


--
-- TOC entry 2987 (class 0 OID 41269)
-- Dependencies: 201
-- Data for Name: etat_commande; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.etat_commande (id, etat) FROM stdin;
1	En attente de pr�paration
2	En pr�paration
3	En attente de livraison
4	En livraison
5	Achemin�e
6	Annul�e
\.


--
-- TOC entry 3003 (class 0 OID 41333)
-- Dependencies: 217
-- Data for Name: ingredient; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ingredient (id, reference, nom) FROM stdin;
1	farine.pate.a.pain	Farine
2	sel	Sel
3	levure	Levure
4	huile.olive.bio	Huile d'olive
5	sce.tom	Sauce tomate
6	crme.frche	Cr�me fra�che
7	frmge.mozz	Mozzarela fra�che
8	frmge.chvre	Fromage de ch�vres
9	frmge.ggzla	Gorgonzola
10	frmge.scamorza	Scamorza fum�e
11	frmge.parmigiano	Parmigiano
12	hrbe.bslc	Basilic
13	hrbe.rqtte	Roquette
14	hrbe.cibltte	Ciboulette
15	vde.jb.fm	Speck
16	vde.jb.cuit	Rostello
17	vde.jb	Jambon
18	vde.bcn	Bacon
19	vde.plet	Poulet
20	psson.smon.fm	Saumon fum�
21	leg.olv.nre	Olive noire
22	leg.champ.prs	Champignon de Paris
23	leg.aubrgn	Aubergine
24	leg.crgette	Courgette
25	leg.tmte	Tomate
26	leg.tmte.crse	Tomate cerise
27	leg.ogn	Oignon
28	oeuf	Oeuf
29	miel	Miel
\.


--
-- TOC entry 3006 (class 0 OID 41346)
-- Dependencies: 220
-- Data for Name: menu; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.menu (produit_id, reference, nom, description, prix, cree_par, disponible, date_creation) FROM stdin;
1	pz.marga.jnr	Magarita junior	Concass� de tomates, Mozzarela, Feuilles de basilic	12.50	1	t	2018-08-18 07:08:47
2	pz.marga.moy	Magarita moyenne	Concass� de tomates, Mozzarela, Feuilles de basilic	14.50	1	t	2018-08-18 07:10:34
3	pz.marga.sen	Magarita senior	Concass� de tomates, Mozzarela, Feuilles de basilic	16.50	1	t	2018-08-18 07:11:43
4	pz.marga.hulk	Magarita hulk	Concass� de tomates, Mozzarela, Feuilles de basilic	18.50	1	t	2018-08-18 07:13:12
5	pz.ch.miel.jnr	Ch�vre miel junior	Cr�me, Miel, Mozzarela, Fromage de ch�vre, Speck, Roquette	14.50	1	t	2018-08-18 07:16:19
6	pz.ch.miel.moy	Ch�vre miel moyenne	Cr�me, Miel, Mozzarela, Fromage de ch�vre, Speck, Roquette	16.50	1	t	2018-08-18 07:17:12
7	pz.ch.miel.sen	Ch�vre miel senior	Cr�me, Miel, Mozzarela, Fromage de ch�vre, Speck, Roquette	18.50	1	t	2018-08-18 07:19:03
8	pz.ch.miel.hulk	Ch�vre miel hulk	Cr�me, Miel, Mozzarela, Fromage de ch�vre, Speck, Roquette	20.50	1	t	2018-08-18 07:19:57
9	pz.rgna.jnr	Regina Rostello junior	Concass� de tomates, Mozzarela, Rostello, Champignons, Olives noires	14.50	1	t	2018-08-18 07:21:48
10	pz.rgna.moy	Regina Rostello moyenne	Concass� de tomates, Mozzarela, Rostello, Champignons, Olives noires	16.50	1	t	2018-08-18 07:22:47
11	pz.rgna.sen	Regina Rostello senior	Concass� de tomates, Mozzarela, Rostello, Champignons, Olives noires	18.50	1	t	2018-08-18 07:24:25
12	pz.rgna.hulk	Regina Rostello hulk	Concass� de tomates, Mozzarela, Rostello, Champignons, Olives noires	20.50	1	t	2018-08-18 07:25:42
13	pz.4frg.jnr	4 Fromaggi junior	Concass� de tomates, Mozzarela, Gorgonzola, Scamorza fum�e, Parmigiano	16.50	1	t	2018-08-18 07:27:33
14	pz.4frg.moy	4 Fromaggi moyenne	Concass� de tomates, Mozzarela, Gorgonzola, Scamorza fum�e, Parmigiano	18.50	1	t	2018-08-18 07:28:03
15	pz.4frg.sen	4 Fromaggi senior	Concass� de tomates, Mozzarela, Gorgonzola, Scamorza fum�e, Parmigiano	20.50	1	t	2018-08-18 07:28:57
16	pz.4frg.hulk	4 Fromaggi hulk	Concass� de tomates, Mozzarela, Gorgonzola, Scamorza fum�e, Parmigiano	22.50	1	t	2018-08-18 07:29:18
17	pz.crbnra.jnr	Carbonara junior	Cr�me fra�che, Mozzarela, Bacon, Oeuf, Parmigiano	14.50	1	t	2018-08-18 07:33:42
18	pz.crbnra.moy	Carbonara moyenne	Cr�me fra�che, Mozzarela, Bacon, Oeuf, Parmigiano	16.50	1	t	2018-08-18 07:35:17
19	pz.crbnra.sen	Carbonara senior	Cr�me fra�che, Mozzarela, Bacon, Oeuf, Parmigiano	18.50	1	t	2018-08-18 07:36:35
20	pz.crbnra.hulk	Carbonara hulk	Cr�me fra�che, Mozzarela, Bacon, Oeuf, Parmigiano	20.50	1	t	2018-08-18 07:38:51
21	pz.spe.pizz.jnr	Speciale Pizza�olo junior	Concass� de tomates, Mozzarela, Jambon, Oeuf, Cr�me fra�che, Ciboulette	15.50	1	t	2018-08-18 07:41:12
22	pz.spe.pizz.moy	Speciale Pizza�olo moyenne	Concass� de tomates, Mozzarela, Jambon, Oeuf, Cr�me fra�che, Ciboulette	17.50	1	t	2018-08-18 07:42:42
23	pz.spe.pizz.sen	Speciale Pizza�olo senior	Concass� de tomates, Mozzarela, Jambon, Oeuf, Cr�me fra�che, Ciboulette	19.50	1	t	2018-08-18 07:44:36
24	pz.spe.pizz.hulk	Speciale Pizza�olo hulk	Concass� de tomates, Mozzarela, Jambon, Oeuf, Cr�me fra�che, Ciboulette	21.50	1	t	2018-08-18 07:48:41
25	pz.veg.jnr	V�g�tarienne junior	Concass� de tomates, Mozzarela, Aubergine, Courgette, Oignon, Tomates cerises, Olives noires	14.50	1	t	2018-08-18 07:51:03
26	pz.veg.moy	V�g�tarienne moyenne	Concass� de tomates, Mozzarela, Aubergine, Courgette, Oignon, Tomates cerises, Olives noires	16.50	1	t	2018-08-18 07:51:51
27	pz.veg.sen	V�g�tarienne senior	Concass� de tomates, Mozzarela, Aubergine, Courgette, Oignon, Tomates cerises, Olives noires	18.50	1	t	2018-08-18 07:52:37
28	pz.veg.hulk	V�g�tarienne hulk	Concass� de tomates, Mozzarela, Aubergine, Courgette, Oignon, Tomates cerises, Olives noires	20.50	1	t	2018-08-18 07:54:07
29	pz.calz.Pollo.jnr	Calzone Pollo e Scamorza junior	Concass� de tomates, Cr�me fra�che, Mozzarela, Eminc�s de poulet, Scamorza fum�e	17.50	1	t	2018-08-18 07:57:34
30	pz.calz.Pollo.moy	Calzone Pollo e Scamorza moyenne	Concass� de tomates, Cr�me fra�che, Mozzarela, Eminc�s de poulet, Scamorza fum�e	19.50	1	t	2018-08-18 07:58:47
31	pz.calz.Pollo.sen	Calzone Pollo e Scamorza senior	Concass� de tomates, Cr�me fra�che, Mozzarela, Eminc�s de poulet, Scamorza fum�e	21.50	1	t	2018-08-18 08:01:17
32	pz.calz.Pollo.hulk	Calzone Pollo e Scamorza hulk	Concass� de tomates, Cr�me fra�che, Mozzarela, Eminc�s de poulet, Scamorza fum�e	23.50	1	t	2018-08-18 08:02:09
33	pz.slm.jnr	Salmone e Basilico junior	Cr�me fra�che, Mozzarela, Saumon fum�, Basilic	19.00	1	t	2018-08-18 08:03:58
34	pz.slm.moy	Salmone e Basilico moyenne	Cr�me fra�che, Mozzarela, Saumon fum�, Basilic	21.00	1	t	2018-08-18 08:04:17
35	pz.slm.sen	Salmone e Basilico senior	Cr�me fra�che, Mozzarela, Saumon fum�, Basilic	23.00	1	t	2018-08-18 08:06:03
36	pz.slm.hulk	Salmone e Basilico hulk	Cr�me fra�che, Mozzarela, Saumon fum�, Basilic	25.00	1	t	2018-08-18 08:07:31
37	bs.evian.sml	Evian	Eau de montagne - 50cl	2.00	2	t	2018-08-19 15:08:47
38	bs.evian.lrg	Evian	Eau de montagne - 1,5L	3.50	2	t	2018-08-19 15:09:36
39	bs.spel.sml	San Pellegrino	Eau p�tillante - 50cl 	2.50	2	t	2018-08-19 15:10:21
40	bs.spel.lrg	San Pellegrino	Eau p�tillante - 1,5L	4.00	2	t	2018-08-19 15:10:59
41	bs.pepsi.sml	Pepsi	Soda - 33cl	2.50	2	t	2018-08-19 15:12:14
42	bs.pepsi.moy	Pepsi	Soda - 50 cl	3.00	2	t	2018-08-19 15:13:52
43	bs.pepsi.btl	Pepsi	Soda - 1,5L	4.50	2	t	2018-08-19 15:15:08
44	bs.fta.org.sml	Fanta orange	Soda - 33cl	2.50	2	t	2018-08-19 15:17:59
45	bs.fta.org.moy	Fanta orange	Soda - 50cl	3.00	2	t	2018-08-19 15:19:14
46	bs.fta.org.btl	Fanta orange	Soda - 1,5L	4.50	2	t	2018-08-19 15:20:01
47	bs.7up.sml	7up	Soda - 33cl	2.50	2	t	2018-08-19 15:21:35
48	bs.7up.moy	7up	Soda - 50cl	3.00	2	t	2018-08-19 15:22:37
49	bs.7up.btl	7up	Soda - 1,5L	4.50	2	t	2018-08-19 15:23:23
50	bs.jo.sml	Jus d'orange	Jus d'orange - 25cl	3.50	2	t	2018-08-19 15:24:43
51	bs.hnk.sml	Heineken	Bi�re - 33cl	4.00	2	f	2018-08-19 15:25:17
52	bs.hnk.moy	Heineken	Bi�re - 50cl	6.00	2	t	2018-08-19 15:26:54
\.


--
-- TOC entry 2993 (class 0 OID 41293)
-- Dependencies: 207
-- Data for Name: mode_reglement; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mode_reglement (id, type) FROM stdin;
1	Carte bancaire
2	Esp�ces
3	Ch�que
4	Ticket(s) restaurant
5	Ch�que(s) vacances
\.


--
-- TOC entry 3017 (class 0 OID 41396)
-- Dependencies: 231
-- Data for Name: panier; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.panier (id_commande, produit_id, quantite) FROM stdin;
1	12	1
1	37	1
1	14	1
1	50	1
2	17	2
2	6	2
3	36	1
3	34	1
3	50	2
4	33	1
4	27	1
4	39	1
4	40	1
5	7	1
5	9	1
5	13	1
5	50	3
6	2	3
6	3	2
6	49	6
7	31	1
7	29	1
7	52	1
7	41	1
8	2	1
8	52	1
9	7	2
9	37	2
10	11	3
10	17	1
10	50	4
11	19	1
11	39	1
12	21	1
12	40	1
13	30	1
13	44	1
\.


--
-- TOC entry 3007 (class 0 OID 41352)
-- Dependencies: 221
-- Data for Name: pizza; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pizza (produit_id, taille) FROM stdin;
1	1
2	2
3	3
4	4
5	1
6	2
7	3
8	4
9	1
10	2
11	3
12	4
13	1
14	2
15	3
16	4
17	1
18	2
19	3
20	4
21	1
22	2
23	3
24	4
25	1
26	2
27	3
28	4
29	1
30	2
31	3
32	4
33	1
34	2
35	3
36	4
\.


--
-- TOC entry 3008 (class 0 OID 41357)
-- Dependencies: 222
-- Data for Name: recette; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recette (id_ingredient, pizza_id, quantite) FROM stdin;
1	1	1
2	1	1
3	1	1
4	1	1
5	1	1
7	1	1
12	1	1
1	2	2
2	2	2
3	2	2
4	2	2
5	2	2
7	2	2
12	2	2
1	3	3
2	3	3
3	3	3
4	3	3
5	3	3
7	3	3
12	3	3
1	4	4
2	4	4
3	4	4
4	4	4
5	4	4
7	4	4
12	4	4
1	5	1
2	5	1
3	5	1
4	5	1
6	5	1
29	5	1
7	5	1
8	5	1
15	5	1
13	5	1
1	6	2
2	6	2
3	6	2
4	6	2
6	6	2
29	6	2
7	6	2
8	6	2
15	6	2
13	6	2
1	7	3
2	7	3
3	7	3
4	7	3
6	7	3
29	7	3
7	7	3
8	7	3
15	7	3
13	7	3
1	8	4
2	8	4
3	8	4
4	8	4
6	8	4
29	8	4
7	8	4
8	8	4
15	8	4
13	8	4
1	9	1
2	9	1
3	9	1
4	9	1
5	9	1
7	9	1
16	9	1
22	9	1
21	9	1
1	10	2
2	10	2
3	10	2
4	10	2
5	10	2
7	10	2
16	10	2
22	10	2
21	10	2
1	11	3
2	11	3
3	11	3
4	11	3
5	11	3
7	11	3
16	11	3
22	11	3
21	11	3
1	12	4
2	12	4
3	12	4
4	12	4
5	12	4
7	12	4
16	12	4
22	12	4
21	12	4
1	13	1
2	13	1
3	13	1
4	13	1
5	13	1
7	13	1
9	13	1
10	13	1
11	13	1
1	14	2
2	14	2
3	14	2
4	14	2
5	14	2
7	14	2
9	14	2
10	14	2
11	14	2
1	15	3
2	15	3
3	15	3
4	15	3
5	15	3
7	15	3
9	15	3
10	15	3
11	15	3
1	16	4
2	16	4
3	16	4
4	16	4
5	16	4
7	16	4
9	16	4
10	16	4
11	16	4
1	17	1
2	17	1
3	17	1
4	17	1
6	17	1
7	17	1
18	17	1
28	17	1
11	17	1
1	18	2
2	18	2
3	18	2
4	18	2
6	18	2
7	18	2
18	18	2
28	18	2
11	18	2
1	19	3
2	19	3
3	19	3
4	19	3
6	19	3
7	19	3
18	19	3
28	19	3
11	19	3
1	20	4
2	20	4
3	20	4
4	20	4
6	20	4
7	20	4
18	20	4
28	20	4
11	20	4
1	21	1
2	21	1
3	21	1
4	21	1
5	21	1
7	21	1
17	21	1
28	21	1
6	21	1
14	21	1
1	22	2
2	22	2
3	22	2
4	22	2
5	22	2
7	22	2
17	22	2
28	22	2
6	22	2
14	22	2
1	23	3
2	23	3
3	23	3
4	23	3
5	23	3
7	23	3
17	23	3
28	23	3
6	23	3
14	23	3
1	24	4
2	24	1
3	24	1
4	24	4
5	24	4
7	24	4
17	24	4
28	24	4
6	24	4
14	24	4
1	25	1
2	25	1
3	25	1
4	25	1
5	25	1
23	25	1
24	25	1
25	25	1
27	25	1
7	25	1
26	25	1
21	25	1
1	26	2
2	26	2
3	26	2
4	26	2
5	26	2
23	26	2
24	26	2
25	26	2
27	26	2
7	26	2
26	26	2
21	26	2
1	27	3
2	27	3
3	27	3
4	27	3
5	27	3
23	27	3
24	27	3
25	27	3
27	27	3
7	27	3
26	27	3
21	27	3
1	28	4
2	28	4
3	28	4
4	28	4
5	28	4
23	28	4
24	28	4
25	28	4
27	28	4
7	28	4
26	28	4
21	28	4
1	29	1
2	29	1
3	29	1
4	29	1
5	29	1
6	29	1
7	29	1
19	29	1
10	29	1
1	30	2
2	30	2
3	30	2
4	30	2
5	30	2
6	30	2
7	30	2
19	30	2
10	30	2
1	31	3
2	31	3
3	31	3
4	31	3
5	31	3
6	31	3
7	31	3
19	31	3
10	31	3
1	32	4
2	32	4
3	32	4
4	32	4
5	32	4
6	32	4
7	32	4
19	32	4
10	32	4
1	33	1
2	33	1
3	33	1
4	33	1
6	33	1
7	33	1
20	33	1
12	33	1
1	34	2
2	34	2
3	34	2
4	34	2
6	34	2
7	34	2
20	34	2
12	34	2
1	35	3
2	35	3
3	35	3
4	35	3
6	35	3
7	35	3
20	35	3
12	35	3
1	36	4
2	36	4
3	36	4
4	36	4
6	36	4
7	36	4
20	36	4
12	36	4
\.


--
-- TOC entry 2995 (class 0 OID 41301)
-- Dependencies: 209
-- Data for Name: restaurant; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.restaurant (id, nom, adresse_restaurant_id) FROM stdin;
1	OCP Bastille	1
2	OCP Nation	2
3	OCP Bercy	3
4	OCP R�publique	4
5	OCP Gambetta	5
\.


--
-- TOC entry 2991 (class 0 OID 41285)
-- Dependencies: 205
-- Data for Name: role; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.role (id, type) FROM stdin;
1	Hotesse
2	Livreur
3	Manager
\.


--
-- TOC entry 3010 (class 0 OID 41367)
-- Dependencies: 224
-- Data for Name: stock_bar; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stock_bar (id_restaurant, boisson_id, quantite) FROM stdin;
1	37	58
1	38	14
1	39	49
1	40	78
1	41	62
1	42	45
1	43	26
1	44	65
1	45	75
1	46	196
1	47	148
1	48	46
1	49	16
1	50	124
1	51	59
1	52	89
2	37	56
2	38	196
2	39	156
2	40	75
2	41	114
2	42	163
2	43	18
2	44	46
2	45	45
2	46	124
2	47	89
2	48	23
2	49	151
2	50	145
2	51	46
2	52	123
3	37	104
3	38	163
3	39	75
3	40	146
3	41	186
3	42	56
3	43	196
3	44	145
3	45	103
3	46	118
3	47	66
3	48	144
3	49	163
3	50	34
3	51	145
3	52	163
4	37	146
4	38	94
4	39	75
4	40	118
4	41	102
4	42	99
4	43	79
4	44	77
4	45	176
4	46	86
4	47	46
4	48	74
4	49	176
4	50	100
4	51	84
4	52	93
5	37	45
5	38	56
5	39	43
5	40	176
5	41	161
5	42	156
5	43	48
5	44	95
5	45	109
5	46	73
5	47	123
5	48	127
5	49	118
5	50	153
5	51	86
5	52	46
\.


--
-- TOC entry 3004 (class 0 OID 41339)
-- Dependencies: 218
-- Data for Name: stock_cuisine; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stock_cuisine (id_ingredient, id_restaurant, quantite) FROM stdin;
1	1	205
2	1	248
3	1	231
4	1	146
5	1	248
6	1	115
7	1	62
8	1	178
9	1	99
10	1	145
11	1	185
12	1	113
13	1	263
14	1	146
15	1	96
16	1	141
17	1	452
18	1	234
19	1	100
20	1	57
21	1	86
22	1	204
23	1	56
24	1	76
25	1	156
26	1	196
27	1	77
28	1	175
29	1	635
1	2	145
2	2	186
3	2	75
4	2	116
5	2	153
6	2	102
7	2	106
8	2	156
9	2	116
10	2	76
11	2	146
12	2	209
13	2	146
14	2	235
15	2	256
16	2	56
17	2	245
18	2	75
19	2	65
20	2	39
21	2	46
22	2	76
23	2	64
24	2	156
25	2	146
26	2	175
27	2	163
28	2	107
29	2	79
1	3	102
2	3	140
3	3	146
4	3	118
5	3	186
6	3	112
7	3	70
8	3	138
9	3	170
10	3	110
11	3	200
12	3	240
13	3	296
14	3	176
15	3	169
16	3	234
17	3	146
18	3	134
19	3	86
20	3	146
21	3	160
22	3	100
23	3	176
24	3	134
25	3	146
26	3	176
27	3	119
28	3	76
29	3	86
1	4	53
2	4	176
3	4	280
4	4	270
5	4	180
6	4	176
7	4	116
8	4	186
9	4	146
10	4	176
11	4	136
12	4	176
13	4	100
14	4	265
15	4	246
16	4	168
17	4	186
18	4	139
19	4	140
20	4	269
21	4	275
22	4	165
23	4	76
24	4	119
25	4	176
26	4	148
27	4	86
28	4	143
29	4	76
1	5	76
2	5	49
3	5	101
4	5	256
5	5	263
6	5	87
7	5	178
8	5	86
9	5	94
10	5	49
11	5	136
12	5	186
13	5	115
14	5	93
15	5	109
16	5	178
17	5	146
18	5	116
19	5	176
20	5	207
21	5	79
22	5	126
23	5	116
24	5	168
25	5	176
26	5	99
27	5	117
28	5	116
29	5	196
\.


--
-- TOC entry 2985 (class 0 OID 41258)
-- Dependencies: 199
-- Data for Name: taille_boisson; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.taille_boisson (id, taille) FROM stdin;
1	25cl
2	33cl
3	50cl
4	1,5L
\.


--
-- TOC entry 2983 (class 0 OID 41247)
-- Dependencies: 197
-- Data for Name: taille_pizza; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.taille_pizza (id, taille) FROM stdin;
1	Junior
2	Moyenne
3	Senior
4	Hulk
\.


--
-- TOC entry 3041 (class 0 OID 0)
-- Dependencies: 212
-- Name: adresse_compte_utilisateur_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.adresse_compte_utilisateur_id_seq', 10, true);


--
-- TOC entry 3042 (class 0 OID 0)
-- Dependencies: 210
-- Name: adresse_livraison_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.adresse_livraison_id_seq', 13, true);


--
-- TOC entry 3043 (class 0 OID 0)
-- Dependencies: 202
-- Name: adresse_restaurant_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.adresse_restaurant_id_seq', 5, true);


--
-- TOC entry 3044 (class 0 OID 0)
-- Dependencies: 229
-- Name: commande_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.commande_id_seq', 13, true);


--
-- TOC entry 3045 (class 0 OID 0)
-- Dependencies: 214
-- Name: compte_personnel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.compte_personnel_id_seq', 11, true);


--
-- TOC entry 3046 (class 0 OID 0)
-- Dependencies: 227
-- Name: compte_utilisateur_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.compte_utilisateur_id_seq', 10, true);


--
-- TOC entry 3047 (class 0 OID 0)
-- Dependencies: 225
-- Name: coordonnees_livraison_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.coordonnees_livraison_id_seq', 13, true);


--
-- TOC entry 3048 (class 0 OID 0)
-- Dependencies: 200
-- Name: etat_commande_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.etat_commande_id_seq', 6, true);


--
-- TOC entry 3049 (class 0 OID 0)
-- Dependencies: 216
-- Name: ingredient_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ingredient_id_seq', 29, true);


--
-- TOC entry 3050 (class 0 OID 0)
-- Dependencies: 219
-- Name: menu_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.menu_id_seq', 52, true);


--
-- TOC entry 3051 (class 0 OID 0)
-- Dependencies: 206
-- Name: mode_reglement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.mode_reglement_id_seq', 5, true);


--
-- TOC entry 3052 (class 0 OID 0)
-- Dependencies: 208
-- Name: restaurant_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.restaurant_id_seq', 5, true);


--
-- TOC entry 3053 (class 0 OID 0)
-- Dependencies: 204
-- Name: role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.role_id_seq', 3, true);


--
-- TOC entry 3054 (class 0 OID 0)
-- Dependencies: 198
-- Name: taille_boisson_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.taille_boisson_id_seq', 4, true);


--
-- TOC entry 3055 (class 0 OID 0)
-- Dependencies: 196
-- Name: taille_pizza_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.taille_pizza_id_seq', 4, true);


--
-- TOC entry 2812 (class 2606 OID 41322)
-- Name: adresse_compte_utilisateur adresse_compte_utilisateur_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adresse_compte_utilisateur
    ADD CONSTRAINT adresse_compte_utilisateur_pk PRIMARY KEY (id);


--
-- TOC entry 2810 (class 2606 OID 41314)
-- Name: adresse_livraison adresse_livraison_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adresse_livraison
    ADD CONSTRAINT adresse_livraison_pk PRIMARY KEY (id);


--
-- TOC entry 2802 (class 2606 OID 41282)
-- Name: adresse_restaurant adresse_restaurant_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.adresse_restaurant
    ADD CONSTRAINT adresse_restaurant_pk PRIMARY KEY (id);


--
-- TOC entry 2826 (class 2606 OID 41366)
-- Name: boisson boisson_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.boisson
    ADD CONSTRAINT boisson_pk PRIMARY KEY (produit_id);


--
-- TOC entry 2834 (class 2606 OID 41395)
-- Name: commande commande_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.commande
    ADD CONSTRAINT commande_pk PRIMARY KEY (id);


--
-- TOC entry 2814 (class 2606 OID 41330)
-- Name: compte_personnel compte_personnel_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compte_personnel
    ADD CONSTRAINT compte_personnel_pk PRIMARY KEY (id);


--
-- TOC entry 2832 (class 2606 OID 41387)
-- Name: compte_utilisateur compte_utilisateur_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compte_utilisateur
    ADD CONSTRAINT compte_utilisateur_pk PRIMARY KEY (id);


--
-- TOC entry 2830 (class 2606 OID 41379)
-- Name: coordonnees_livraison coordonnees_livraison_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coordonnees_livraison
    ADD CONSTRAINT coordonnees_livraison_pk PRIMARY KEY (id);


--
-- TOC entry 2800 (class 2606 OID 41274)
-- Name: etat_commande etat_commande_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.etat_commande
    ADD CONSTRAINT etat_commande_pk PRIMARY KEY (id);


--
-- TOC entry 2816 (class 2606 OID 41338)
-- Name: ingredient ingredient_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ingredient
    ADD CONSTRAINT ingredient_pk PRIMARY KEY (id);


--
-- TOC entry 2820 (class 2606 OID 41351)
-- Name: menu menu_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu
    ADD CONSTRAINT menu_pk PRIMARY KEY (produit_id);


--
-- TOC entry 2806 (class 2606 OID 41298)
-- Name: mode_reglement mode_reglement_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mode_reglement
    ADD CONSTRAINT mode_reglement_pk PRIMARY KEY (id);


--
-- TOC entry 2836 (class 2606 OID 41400)
-- Name: panier panier_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.panier
    ADD CONSTRAINT panier_pk PRIMARY KEY (id_commande, produit_id);


--
-- TOC entry 2822 (class 2606 OID 41356)
-- Name: pizza pizza_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pizza
    ADD CONSTRAINT pizza_pk PRIMARY KEY (produit_id);


--
-- TOC entry 2824 (class 2606 OID 41361)
-- Name: recette recette_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recette
    ADD CONSTRAINT recette_pk PRIMARY KEY (id_ingredient, pizza_id);


--
-- TOC entry 2808 (class 2606 OID 41306)
-- Name: restaurant restaurant_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.restaurant
    ADD CONSTRAINT restaurant_pk PRIMARY KEY (id);


--
-- TOC entry 2804 (class 2606 OID 41290)
-- Name: role role_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role
    ADD CONSTRAINT role_pk PRIMARY KEY (id);


--
-- TOC entry 2828 (class 2606 OID 41371)
-- Name: stock_bar stock_bar_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_bar
    ADD CONSTRAINT stock_bar_pk PRIMARY KEY (id_restaurant, boisson_id);


--
-- TOC entry 2818 (class 2606 OID 41343)
-- Name: stock_cuisine stock_cuisine_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_cuisine
    ADD CONSTRAINT stock_cuisine_pk PRIMARY KEY (id_ingredient, id_restaurant);


--
-- TOC entry 2798 (class 2606 OID 41266)
-- Name: taille_boisson taille_boisson_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.taille_boisson
    ADD CONSTRAINT taille_boisson_pk PRIMARY KEY (id);


--
-- TOC entry 2796 (class 2606 OID 41255)
-- Name: taille_pizza taille_pizza_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.taille_pizza
    ADD CONSTRAINT taille_pizza_pk PRIMARY KEY (id);


--
-- TOC entry 2851 (class 2606 OID 41451)
-- Name: compte_utilisateur adresse_compte_utilisateur_compte_utilisateur_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compte_utilisateur
    ADD CONSTRAINT adresse_compte_utilisateur_compte_utilisateur_fk FOREIGN KEY (adresse_compte_utilisateur_id) REFERENCES public.adresse_compte_utilisateur(id);


--
-- TOC entry 2850 (class 2606 OID 41446)
-- Name: coordonnees_livraison adresse_livraison_coordonnees_livraison_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coordonnees_livraison
    ADD CONSTRAINT adresse_livraison_coordonnees_livraison_fk FOREIGN KEY (adresse_livraison_id) REFERENCES public.adresse_livraison(id);


--
-- TOC entry 2837 (class 2606 OID 41416)
-- Name: restaurant adresse_restaurant_restaurant_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.restaurant
    ADD CONSTRAINT adresse_restaurant_restaurant_fk FOREIGN KEY (adresse_restaurant_id) REFERENCES public.adresse_restaurant(id);


--
-- TOC entry 2849 (class 2606 OID 41501)
-- Name: stock_bar boisson_stock_bar_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_bar
    ADD CONSTRAINT boisson_stock_bar_fk FOREIGN KEY (boisson_id) REFERENCES public.boisson(produit_id);


--
-- TOC entry 2860 (class 2606 OID 41516)
-- Name: panier commande_panier_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.panier
    ADD CONSTRAINT commande_panier_fk FOREIGN KEY (id_commande) REFERENCES public.commande(id);


--
-- TOC entry 2855 (class 2606 OID 41456)
-- Name: commande compte_personnel_commande_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.commande
    ADD CONSTRAINT compte_personnel_commande_fk FOREIGN KEY (hotesse_id) REFERENCES public.compte_personnel(id);


--
-- TOC entry 2856 (class 2606 OID 41461)
-- Name: commande compte_personnel_commande_fk1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.commande
    ADD CONSTRAINT compte_personnel_commande_fk1 FOREIGN KEY (livreur_id) REFERENCES public.compte_personnel(id);


--
-- TOC entry 2841 (class 2606 OID 41466)
-- Name: menu compte_personnel_menu_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu
    ADD CONSTRAINT compte_personnel_menu_fk FOREIGN KEY (cree_par) REFERENCES public.compte_personnel(id);


--
-- TOC entry 2858 (class 2606 OID 41511)
-- Name: commande compte_utilisateur_commande_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.commande
    ADD CONSTRAINT compte_utilisateur_commande_fk FOREIGN KEY (compte_utilisateur_id) REFERENCES public.compte_utilisateur(id);


--
-- TOC entry 2857 (class 2606 OID 41506)
-- Name: commande coordonnees_livraison_commande_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.commande
    ADD CONSTRAINT coordonnees_livraison_commande_fk FOREIGN KEY (coordonnees_livraison_id) REFERENCES public.coordonnees_livraison(id);


--
-- TOC entry 2852 (class 2606 OID 41411)
-- Name: commande etat_commande_commande_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.commande
    ADD CONSTRAINT etat_commande_commande_fk FOREIGN KEY (etat_commande) REFERENCES public.etat_commande(id);


--
-- TOC entry 2840 (class 2606 OID 41471)
-- Name: stock_cuisine ingredient_composition_stock_cuisine_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_cuisine
    ADD CONSTRAINT ingredient_composition_stock_cuisine_fk FOREIGN KEY (id_ingredient) REFERENCES public.ingredient(id);


--
-- TOC entry 2844 (class 2606 OID 41476)
-- Name: recette ingredient_recette_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recette
    ADD CONSTRAINT ingredient_recette_fk FOREIGN KEY (id_ingredient) REFERENCES public.ingredient(id);


--
-- TOC entry 2847 (class 2606 OID 41486)
-- Name: boisson menu_boisson_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.boisson
    ADD CONSTRAINT menu_boisson_fk FOREIGN KEY (produit_id) REFERENCES public.menu(produit_id);


--
-- TOC entry 2843 (class 2606 OID 41491)
-- Name: pizza menu_pizza_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pizza
    ADD CONSTRAINT menu_pizza_fk FOREIGN KEY (produit_id) REFERENCES public.menu(produit_id);


--
-- TOC entry 2853 (class 2606 OID 41426)
-- Name: commande mode_reglement_commande_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.commande
    ADD CONSTRAINT mode_reglement_commande_fk FOREIGN KEY (mode_reglement) REFERENCES public.mode_reglement(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 2845 (class 2606 OID 41496)
-- Name: recette pizza_recette_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recette
    ADD CONSTRAINT pizza_recette_fk FOREIGN KEY (pizza_id) REFERENCES public.pizza(produit_id);


--
-- TOC entry 2859 (class 2606 OID 41481)
-- Name: panier produit_contenu_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.panier
    ADD CONSTRAINT produit_contenu_fk FOREIGN KEY (produit_id) REFERENCES public.menu(produit_id);


--
-- TOC entry 2854 (class 2606 OID 41441)
-- Name: commande restaurant_commande_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.commande
    ADD CONSTRAINT restaurant_commande_fk FOREIGN KEY (restaurant_id) REFERENCES public.restaurant(id);


--
-- TOC entry 2838 (class 2606 OID 41421)
-- Name: compte_personnel role_compte_personnel_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compte_personnel
    ADD CONSTRAINT role_compte_personnel_fk FOREIGN KEY (role) REFERENCES public.role(id);


--
-- TOC entry 2848 (class 2606 OID 41431)
-- Name: stock_bar stock_composition_stock_bar_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_bar
    ADD CONSTRAINT stock_composition_stock_bar_fk FOREIGN KEY (id_restaurant) REFERENCES public.restaurant(id);


--
-- TOC entry 2839 (class 2606 OID 41436)
-- Name: stock_cuisine stock_composition_stock_cuisine_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_cuisine
    ADD CONSTRAINT stock_composition_stock_cuisine_fk FOREIGN KEY (id_restaurant) REFERENCES public.restaurant(id);


--
-- TOC entry 2846 (class 2606 OID 41406)
-- Name: boisson taille_boisson_boisson_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.boisson
    ADD CONSTRAINT taille_boisson_boisson_fk FOREIGN KEY (taille) REFERENCES public.taille_boisson(id);


--
-- TOC entry 2842 (class 2606 OID 41401)
-- Name: pizza taille_pizza_pizza_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pizza
    ADD CONSTRAINT taille_pizza_pizza_fk FOREIGN KEY (taille) REFERENCES public.taille_pizza(id);


-- Completed on 2018-09-03 20:02:45

--
-- PostgreSQL database dump complete
--


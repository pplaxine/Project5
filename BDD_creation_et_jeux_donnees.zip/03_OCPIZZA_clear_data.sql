BEGIN TRANSACTION;

--- ===== Purge des tables
DELETE FROM public.panier;
DELETE FROM public.commande;
DELETE FROM public.etat_commande;
DELETE FROM public.mode_reglement;
DELETE FROM public.coordonnees_livraison ;
DELETE FROM public.adresse_livraison;
DELETE FROM public.compte_utilisateur;
DELETE FROM public.adresse_compte_utilisateur;
DELETE FROM public.stock_cuisine;
DELETE FROM public.stock_bar;
DELETE FROM public.recette;
DELETE FROM public.pizza;
DELETE FROM public.boisson;
DELETE FROM public.menu;
DELETE FROM public.ingredient;
DELETE FROM public.taille_pizza;
DELETE FROM public.taille_boisson;
DELETE FROM public.restaurant;
DELETE FROM public.adresse_restaurant;
DELETE FROM public.compte_personnel;
DELETE FROM public.role;


--- ===== R�initialisation des s�quences
SELECT setval('public.taille_pizza_id_seq', 1, false);
SELECT setval('public.taille_boisson_id_seq', 1, false);
SELECT setval('public.etat_commande_id_seq', 1, false);
SELECT setval('public.adresse_restaurant_id_seq', 1, false);
SELECT setval('public.role_id_seq', 1, false);
SELECT setval('public.mode_reglement_id_seq', 1, false); 
SELECT setval('public.restaurant_id_seq', 1, false); 
SELECT setval('public.adresse_livraison_id_seq', 1, false); 
SELECT setval('public.adresse_compte_utilisateur_id_seq', 1, false); 
SELECT setval('public.compte_personnel_id_seq', 1, false); 
SELECT setval('public.ingredient_id_seq', 1, false); 
SELECT setval('public.menu_id_seq', 1, false); 
SELECT setval('public.coordonnees_livraison_id_seq', 1, false); 
SELECT setval('public.compte_utilisateur_id_seq', 1, false); 
SELECT setval('public.commande_id_seq', 1, false); 


COMMIT;



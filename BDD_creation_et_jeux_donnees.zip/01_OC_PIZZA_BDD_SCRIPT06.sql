
CREATE SEQUENCE public.taille_pizza_id_seq;

CREATE TABLE public.taille_pizza (
                id INTEGER NOT NULL DEFAULT nextval('public.taille_pizza_id_seq'),
                taille VARCHAR NOT NULL,
                CONSTRAINT taille_pizza_pk PRIMARY KEY (id)
);


ALTER SEQUENCE public.taille_pizza_id_seq OWNED BY public.taille_pizza.id;

CREATE SEQUENCE public.taille_boisson_id_seq;

CREATE TABLE public.taille_boisson (
                id INTEGER NOT NULL DEFAULT nextval('public.taille_boisson_id_seq'),
                taille VARCHAR NOT NULL,
                CONSTRAINT taille_boisson_pk PRIMARY KEY (id)
);


ALTER SEQUENCE public.taille_boisson_id_seq OWNED BY public.taille_boisson.id;

CREATE SEQUENCE public.etat_commande_id_seq;

CREATE TABLE public.etat_commande (
                id INTEGER NOT NULL DEFAULT nextval('public.etat_commande_id_seq'),
                etat VARCHAR(30) NOT NULL,
                CONSTRAINT etat_commande_pk PRIMARY KEY (id)
);


ALTER SEQUENCE public.etat_commande_id_seq OWNED BY public.etat_commande.id;

CREATE SEQUENCE public.adresse_restaurant_id_seq;

CREATE TABLE public.adresse_restaurant (
                id INTEGER NOT NULL DEFAULT nextval('public.adresse_restaurant_id_seq'),
                numero INTEGER,
                rue VARCHAR(50) NOT NULL,
                Ville VARCHAR(50) NOT NULL,
                code_postal INTEGER NOT NULL,
                CONSTRAINT adresse_restaurant_pk PRIMARY KEY (id)
);


ALTER SEQUENCE public.adresse_restaurant_id_seq OWNED BY public.adresse_restaurant.id;

CREATE SEQUENCE public.role_id_seq;

CREATE TABLE public.role (
                id INTEGER NOT NULL DEFAULT nextval('public.role_id_seq'),
                type VARCHAR(30) NOT NULL,
                CONSTRAINT role_pk PRIMARY KEY (id)
);


ALTER SEQUENCE public.role_id_seq OWNED BY public.role.id;

CREATE SEQUENCE public.mode_reglement_id_seq;

CREATE TABLE public.mode_reglement (
                id INTEGER NOT NULL DEFAULT nextval('public.mode_reglement_id_seq'),
                type VARCHAR(30) NOT NULL,
                CONSTRAINT mode_reglement_pk PRIMARY KEY (id)
);


ALTER SEQUENCE public.mode_reglement_id_seq OWNED BY public.mode_reglement.id;

CREATE SEQUENCE public.restaurant_id_seq;

CREATE TABLE public.restaurant (
                id INTEGER NOT NULL DEFAULT nextval('public.restaurant_id_seq'),
                nom VARCHAR(30) NOT NULL,
                adresse_restaurant_id INTEGER NOT NULL,
                CONSTRAINT restaurant_pk PRIMARY KEY (id)
);


ALTER SEQUENCE public.restaurant_id_seq OWNED BY public.restaurant.id;

CREATE SEQUENCE public.adresse_livraison_id_seq;

CREATE TABLE public.adresse_livraison (
                id INTEGER NOT NULL DEFAULT nextval('public.adresse_livraison_id_seq'),
                numero INTEGER,
                rue VARCHAR(50) NOT NULL,
                Ville VARCHAR(50) NOT NULL,
                code_postal INTEGER NOT NULL,
                CONSTRAINT adresse_livraison_pk PRIMARY KEY (id)
);


ALTER SEQUENCE public.adresse_livraison_id_seq OWNED BY public.adresse_livraison.id;

CREATE SEQUENCE public.adresse_compte_utilisateur_id_seq;

CREATE TABLE public.adresse_compte_utilisateur (
                id INTEGER NOT NULL DEFAULT nextval('public.adresse_compte_utilisateur_id_seq'),
                numero INTEGER,
                rue VARCHAR(50) NOT NULL,
                Ville VARCHAR(50) NOT NULL,
                code_postal INTEGER NOT NULL,
                CONSTRAINT adresse_compte_utilisateur_pk PRIMARY KEY (id)
);


ALTER SEQUENCE public.adresse_compte_utilisateur_id_seq OWNED BY public.adresse_compte_utilisateur.id;

CREATE SEQUENCE public.compte_personnel_id_seq;

CREATE TABLE public.Compte_Personnel (
                id INTEGER NOT NULL DEFAULT nextval('public.compte_personnel_id_seq'),
                identifiant VARCHAR(20) NOT NULL,
                mot_de_passe VARCHAR(20) NOT NULL,
                prenom VARCHAR(30) NOT NULL,
                nom VARCHAR(30) NOT NULL,
                role INTEGER NOT NULL,
                permission_acces INTEGER NOT NULL,
                CONSTRAINT compte_personnel_pk PRIMARY KEY (id)
);


ALTER SEQUENCE public.compte_personnel_id_seq OWNED BY public.Compte_Personnel.id;

CREATE SEQUENCE public.ingredient_id_seq;

CREATE TABLE public.ingredient (
                id INTEGER NOT NULL DEFAULT nextval('public.ingredient_id_seq'),
                reference VARCHAR(20) NOT NULL,
                nom VARCHAR(30) NOT NULL,
                CONSTRAINT ingredient_pk PRIMARY KEY (id)
);


ALTER SEQUENCE public.ingredient_id_seq OWNED BY public.ingredient.id;

CREATE TABLE public.stock_cuisine (
                id_ingredient INTEGER NOT NULL,
                id_restaurant INTEGER NOT NULL,
                quantite INTEGER,
                CONSTRAINT stock_cuisine_pk PRIMARY KEY (id_ingredient, id_restaurant)
);


CREATE SEQUENCE public.menu_id_seq;

CREATE TABLE public.Menu (
                produit_id INTEGER NOT NULL DEFAULT nextval('public.menu_id_seq'),
                reference VARCHAR(20) NOT NULL,
                nom VARCHAR(50) NOT NULL,
                description VARCHAR(500),
                prix NUMERIC(10,2),
                cree_par INTEGER NOT NULL,
                disponible BOOLEAN NOT NULL,
                date_creation TIMESTAMP NOT NULL,
                CONSTRAINT menu_pk PRIMARY KEY (produit_id)
);


ALTER SEQUENCE public.menu_id_seq OWNED BY public.Menu.produit_id;

CREATE TABLE public.pizza (
                produit_id INTEGER NOT NULL,
                taille INTEGER NOT NULL,
                CONSTRAINT pizza_pk PRIMARY KEY (produit_id)
);


CREATE TABLE public.recette (
                id_ingredient INTEGER NOT NULL,
                pizza_id INTEGER NOT NULL,
                quantite INTEGER NOT NULL,
                CONSTRAINT recette_pk PRIMARY KEY (id_ingredient, pizza_id)
);


CREATE TABLE public.boisson (
                produit_id INTEGER NOT NULL,
                taille INTEGER NOT NULL,
                CONSTRAINT boisson_pk PRIMARY KEY (produit_id)
);


CREATE TABLE public.stock_bar (
                id_restaurant INTEGER NOT NULL,
                boisson_id INTEGER NOT NULL,
                quantite INTEGER,
                CONSTRAINT stock_bar_pk PRIMARY KEY (id_restaurant, boisson_id)
);


CREATE SEQUENCE public.coordonnees_livraison_id_seq;

CREATE TABLE public.Coordonnees_Livraison (
                id INTEGER NOT NULL DEFAULT nextval('public.coordonnees_livraison_id_seq'),
                nom VARCHAR(30) NOT NULL,
                prenom VARCHAR(30) NOT NULL,
                adresse_livraison_id INTEGER NOT NULL,
                numero_telephone NUMERIC(20) NOT NULL,
                adresse_email VARCHAR(30) NOT NULL,
                CONSTRAINT coordonnees_livraison_pk PRIMARY KEY (id)
);


ALTER SEQUENCE public.coordonnees_livraison_id_seq OWNED BY public.Coordonnees_Livraison.id;

CREATE SEQUENCE public.compte_utilisateur_id_seq;

CREATE TABLE public.compte_Utilisateur (
                id INTEGER NOT NULL DEFAULT nextval('public.compte_utilisateur_id_seq'),
                identifiant VARCHAR(20) NOT NULL,
                mot_de_passe VARCHAR(20) NOT NULL,
                prenom VARCHAR(30) NOT NULL,
                nom VARCHAR(30) NOT NULL,
                adresse_compte_utilisateur_id INTEGER NOT NULL,
                numero_telephone NUMERIC(20) NOT NULL,
                adresse_email VARCHAR(30) NOT NULL,
                CONSTRAINT compte_utilisateur_pk PRIMARY KEY (id)
);


ALTER SEQUENCE public.compte_utilisateur_id_seq OWNED BY public.compte_Utilisateur.id;

CREATE SEQUENCE public.commande_id_seq;

CREATE TABLE public.Commande (
                id INTEGER NOT NULL DEFAULT nextval('public.commande_id_seq'),
                reference_commande VARCHAR(20) NOT NULL,
                date_creation TIMESTAMP NOT NULL,
                compte_utilisateur_id INTEGER,
                coordonnees_livraison_id INTEGER NOT NULL,
                regle BOOLEAN NOT NULL,
                mode_reglement INTEGER NOT NULL,
                etat_commande INTEGER NOT NULL,
                restaurant_id INTEGER NOT NULL,
                hotesse_id INTEGER,
                livreur_id INTEGER,
                CONSTRAINT commande_pk PRIMARY KEY (id)
);


ALTER SEQUENCE public.commande_id_seq OWNED BY public.Commande.id;

CREATE TABLE public.panier (
                id_commande INTEGER NOT NULL,
                produit_id INTEGER NOT NULL,
                quantite INTEGER NOT NULL,
                CONSTRAINT panier_pk PRIMARY KEY (id_commande, produit_id)
);


ALTER TABLE public.pizza ADD CONSTRAINT taille_pizza_pizza_fk
FOREIGN KEY (taille)
REFERENCES public.taille_pizza (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.boisson ADD CONSTRAINT taille_boisson_boisson_fk
FOREIGN KEY (taille)
REFERENCES public.taille_boisson (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.Commande ADD CONSTRAINT etat_commande_commande_fk
FOREIGN KEY (etat_commande)
REFERENCES public.etat_commande (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.restaurant ADD CONSTRAINT adresse_restaurant_restaurant_fk
FOREIGN KEY (adresse_restaurant_id)
REFERENCES public.adresse_restaurant (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.Compte_Personnel ADD CONSTRAINT role_compte_personnel_fk
FOREIGN KEY (role)
REFERENCES public.role (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.Commande ADD CONSTRAINT mode_reglement_commande_fk
FOREIGN KEY (mode_reglement)
REFERENCES public.mode_reglement (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
DEFERRABLE INITIALLY DEFERRED;

ALTER TABLE public.stock_bar ADD CONSTRAINT stock_composition_stock_bar_fk
FOREIGN KEY (id_restaurant)
REFERENCES public.restaurant (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.stock_cuisine ADD CONSTRAINT stock_composition_stock_cuisine_fk
FOREIGN KEY (id_restaurant)
REFERENCES public.restaurant (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.Commande ADD CONSTRAINT restaurant_commande_fk
FOREIGN KEY (restaurant_id)
REFERENCES public.restaurant (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.Coordonnees_Livraison ADD CONSTRAINT adresse_livraison_coordonnees_livraison_fk
FOREIGN KEY (adresse_livraison_id)
REFERENCES public.adresse_livraison (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.compte_Utilisateur ADD CONSTRAINT adresse_compte_utilisateur_compte_utilisateur_fk
FOREIGN KEY (adresse_compte_utilisateur_id)
REFERENCES public.adresse_compte_utilisateur (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.Commande ADD CONSTRAINT compte_personnel_commande_fk
FOREIGN KEY (hotesse_id)
REFERENCES public.Compte_Personnel (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.Commande ADD CONSTRAINT compte_personnel_commande_fk1
FOREIGN KEY (livreur_id)
REFERENCES public.Compte_Personnel (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.Menu ADD CONSTRAINT compte_personnel_menu_fk
FOREIGN KEY (cree_par)
REFERENCES public.Compte_Personnel (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.stock_cuisine ADD CONSTRAINT ingredient_composition_stock_cuisine_fk
FOREIGN KEY (id_ingredient)
REFERENCES public.ingredient (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.recette ADD CONSTRAINT ingredient_recette_fk
FOREIGN KEY (id_ingredient)
REFERENCES public.ingredient (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.panier ADD CONSTRAINT produit_contenu_fk
FOREIGN KEY (produit_id)
REFERENCES public.Menu (produit_id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.boisson ADD CONSTRAINT menu_boisson_fk
FOREIGN KEY (produit_id)
REFERENCES public.Menu (produit_id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.pizza ADD CONSTRAINT menu_pizza_fk
FOREIGN KEY (produit_id)
REFERENCES public.Menu (produit_id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.recette ADD CONSTRAINT pizza_recette_fk
FOREIGN KEY (pizza_id)
REFERENCES public.pizza (produit_id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.stock_bar ADD CONSTRAINT boisson_stock_bar_fk
FOREIGN KEY (boisson_id)
REFERENCES public.boisson (produit_id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.Commande ADD CONSTRAINT coordonnees_livraison_commande_fk
FOREIGN KEY (coordonnees_livraison_id)
REFERENCES public.Coordonnees_Livraison (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.Commande ADD CONSTRAINT compte_utilisateur_commande_fk
FOREIGN KEY (compte_utilisateur_id)
REFERENCES public.compte_Utilisateur (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

ALTER TABLE public.panier ADD CONSTRAINT commande_panier_fk
FOREIGN KEY (id_commande)
REFERENCES public.Commande (id)
ON DELETE NO ACTION
ON UPDATE NO ACTION
NOT DEFERRABLE;

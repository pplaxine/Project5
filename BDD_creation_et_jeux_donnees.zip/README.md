# Base de données : ocpizza5

Liste des fichiers de création de la base de données **ocpizza5**.

Détail des fichiers :
-   `01_OC_PIZZA_BDD_SCRIPT06` : script de création du schéma de la base de données.
-   `02_OCPIZZA_insert_data` : script d'ajout de données dans la base de données.
-   `03_OCPIZZA_clear_data` : script de purge de la base de données :
    -   supprime toutes les données contenues dans les tables.
    -   réinitialise les séquences.

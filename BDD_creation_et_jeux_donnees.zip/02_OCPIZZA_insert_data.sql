BEGIN TRANSACTION;

--- ================================================================================
--- role
--- ================================================================================

SELECT setval('public.role_id_seq', 1, false);

INSERT INTO public.role (type) VALUES ('Hotesse'),('Livreur'),('Manager');


--- ================================================================================
--- compte_personnel
--- ================================================================================

SELECT setval('public.compte_personnel_id_seq', 1, false);

INSERT INTO public.compte_personnel (identifiant,mot_de_passe,prenom,nom,role,permission_acces) VALUES ('1234','mdp01','Alfred','Mario',3,99);
INSERT INTO public.compte_personnel (identifiant,mot_de_passe,prenom,nom,role,permission_acces) VALUES ('1235','mdp02','Luna','Ninas',3,99);

INSERT INTO public.compte_personnel (identifiant,mot_de_passe,prenom,nom,role,permission_acces) VALUES ('2341','mdp03','Vanessa','Souipa',1,34);
INSERT INTO public.compte_personnel (identifiant,mot_de_passe,prenom,nom,role,permission_acces) VALUES ('2342','mdp04','Harry','Covert',1,34);
INSERT INTO public.compte_personnel (identifiant,mot_de_passe,prenom,nom,role,permission_acces) VALUES ('2343','mdp05','Cyril','Ananas',1,34);
INSERT INTO public.compte_personnel (identifiant,mot_de_passe,prenom,nom,role,permission_acces) VALUES ('2344','mdp06','Kiwi','West',1,34);
INSERT INTO public.compte_personnel (identifiant,mot_de_passe,prenom,nom,role,permission_acces) VALUES ('2345','mdp07','Miley','Cerise',1,34);

INSERT INTO public.compte_personnel (identifiant,mot_de_passe,prenom,nom,role,permission_acces) VALUES ('2431','mdp08','Manu','Papayet',2,6);
INSERT INTO public.compte_personnel (identifiant,mot_de_passe,prenom,nom,role,permission_acces) VALUES ('2332','mdp09','Carla','Brugnon',2,6);
INSERT INTO public.compte_personnel (identifiant,mot_de_passe,prenom,nom,role,permission_acces) VALUES ('2333','mdp10','Lionel','Litchi',2,6);
INSERT INTO public.compte_personnel (identifiant,mot_de_passe,prenom,nom,role,permission_acces) VALUES ('2334','mdp11','Chantal','Goyave',2,6);

--- ================================================================================
--- adresse_restaurant
--- ================================================================================

SELECT setval('public.adresse_restaurant_id_seq', 1, false);

INSERT INTO public.adresse_restaurant (numero, rue,ville,code_postal) VALUES (12,'Place de la Bastille','Paris','75011');
INSERT INTO public.adresse_restaurant (numero, rue,ville,code_postal) VALUES (292,'bld Voltaire','Paris','75011');
INSERT INTO public.adresse_restaurant (numero, rue,ville,code_postal) VALUES (32,'rue Baron le Roy','Paris','75012');
INSERT INTO public.adresse_restaurant (numero, rue,ville,code_postal) VALUES (2,'rue L�on Jouhaux','Paris','75010');
INSERT INTO public.adresse_restaurant (numero, rue,ville,code_postal) VALUES (19,'Place Gambetta','Paris','75020');



--- ================================================================================
--- restaurant
--- ================================================================================

SELECT setval('public.restaurant_id_seq', 1, false); 

INSERT INTO public.restaurant (nom, adresse_restaurant_id) VALUES ('OCP Bastille',1);
INSERT INTO public.restaurant (nom, adresse_restaurant_id) VALUES ('OCP Nation',2);
INSERT INTO public.restaurant (nom, adresse_restaurant_id) VALUES ('OCP Bercy',3);
INSERT INTO public.restaurant (nom, adresse_restaurant_id) VALUES ('OCP R�publique',4);
INSERT INTO public.restaurant (nom, adresse_restaurant_id) VALUES ('OCP Gambetta',5);


--- ================================================================================
--- taille_boisson
--- ================================================================================

SELECT setval('public.taille_boisson_id_seq', 1, false);

INSERT INTO public.taille_boisson (taille) VALUES ('25cl'),('33cl'),('50cl'),('1,5L');


--- ================================================================================
--- taille_pizza
--- ================================================================================

SELECT setval('public.taille_pizza_id_seq', 1, false);

INSERT INTO public.taille_pizza (taille) VALUES ('Junior'),('Moyenne'),('Senior'),('Hulk');


--- ================================================================================
--- ingredient
--- ================================================================================

SELECT setval('public.ingredient_id_seq', 1, false); 

INSERT INTO public.ingredient (reference,nom) VALUES ('farine.pate.a.pain','Farine');
INSERT INTO public.ingredient (reference,nom) VALUES ('sel','Sel');
INSERT INTO public.ingredient (reference,nom) VALUES ('levure','Levure');
INSERT INTO public.ingredient (reference,nom) VALUES ('huile.olive.bio','Huile d''olive');

INSERT INTO public.ingredient (reference,nom) VALUES ('sce.tom','Sauce tomate');

INSERT INTO public.ingredient (reference,nom) VALUES ('crme.frche','Cr�me fra�che');
INSERT INTO public.ingredient (reference,nom) VALUES ('frmge.mozz','Mozzarela fra�che');
INSERT INTO public.ingredient (reference,nom) VALUES ('frmge.chvre','Fromage de ch�vres');
INSERT INTO public.ingredient (reference,nom) VALUES ('frmge.ggzla','Gorgonzola');
INSERT INTO public.ingredient (reference,nom) VALUES ('frmge.scamorza','Scamorza fum�e');
INSERT INTO public.ingredient (reference,nom) VALUES ('frmge.parmigiano','Parmigiano');

INSERT INTO public.ingredient (reference,nom) VALUES ('hrbe.bslc','Basilic');
INSERT INTO public.ingredient (reference,nom) VALUES ('hrbe.rqtte','Roquette');
INSERT INTO public.ingredient (reference,nom) VALUES ('hrbe.cibltte','Ciboulette');

INSERT INTO public.ingredient (reference,nom) VALUES ('vde.jb.fm','Speck');
INSERT INTO public.ingredient (reference,nom) VALUES ('vde.jb.cuit','Rostello');
INSERT INTO public.ingredient (reference,nom) VALUES ('vde.jb','Jambon');
INSERT INTO public.ingredient (reference,nom) VALUES ('vde.bcn','Bacon');
INSERT INTO public.ingredient (reference,nom) VALUES ('vde.plet','Poulet');
INSERT INTO public.ingredient (reference,nom) VALUES ('psson.smon.fm','Saumon fum�');

INSERT INTO public.ingredient (reference,nom) VALUES ('leg.olv.nre','Olive noire');
INSERT INTO public.ingredient (reference,nom) VALUES ('leg.champ.prs','Champignon de Paris');
INSERT INTO public.ingredient (reference,nom) VALUES ('leg.aubrgn','Aubergine');
INSERT INTO public.ingredient (reference,nom) VALUES ('leg.crgette','Courgette');
INSERT INTO public.ingredient (reference,nom) VALUES ('leg.tmte','Tomate');
INSERT INTO public.ingredient (reference,nom) VALUES ('leg.tmte.crse','Tomate cerise');
INSERT INTO public.ingredient (reference,nom) VALUES ('leg.ogn','Oignon');

INSERT INTO public.ingredient (reference,nom) VALUES ('oeuf','Oeuf');
INSERT INTO public.ingredient (reference,nom) VALUES ('miel','Miel');


--- ================================================================================
--- Menu
--- ================================================================================

SELECT setval('public.menu_id_seq', 1, false); 

INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('pz.marga.jnr','Magarita junior','Concass� de tomates, Mozzarela, Feuilles de basilic','12.50',true,1,'2018-08-18 07:08:47');
INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('pz.marga.moy','Magarita moyenne','Concass� de tomates, Mozzarela, Feuilles de basilic','14.50',true,1,'2018-08-18 07:10:34');
INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('pz.marga.sen','Magarita senior','Concass� de tomates, Mozzarela, Feuilles de basilic','16.50',true,1,'2018-08-18 07:11:43');
INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('pz.marga.hulk','Magarita hulk','Concass� de tomates, Mozzarela, Feuilles de basilic','18.50',true,1,'2018-08-18 07:13:12');

INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('pz.ch.miel.jnr','Ch�vre miel junior','Cr�me, Miel, Mozzarela, Fromage de ch�vre, Speck, Roquette','14.50',true,1,'2018-08-18 07:16:19');
INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('pz.ch.miel.moy','Ch�vre miel moyenne','Cr�me, Miel, Mozzarela, Fromage de ch�vre, Speck, Roquette','16.50',true,1,'2018-08-18 07:17:12');
INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('pz.ch.miel.sen','Ch�vre miel senior','Cr�me, Miel, Mozzarela, Fromage de ch�vre, Speck, Roquette','18.50',true,1,'2018-08-18 07:19:03');
INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('pz.ch.miel.hulk','Ch�vre miel hulk','Cr�me, Miel, Mozzarela, Fromage de ch�vre, Speck, Roquette','20.50',true,1,'2018-08-18 07:19:57');

INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('pz.rgna.jnr','Regina Rostello junior','Concass� de tomates, Mozzarela, Rostello, Champignons, Olives noires','14.50',true,1,'2018-08-18 07:21:48');
INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('pz.rgna.moy','Regina Rostello moyenne','Concass� de tomates, Mozzarela, Rostello, Champignons, Olives noires','16.50',true,1,'2018-08-18 07:22:47');
INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('pz.rgna.sen','Regina Rostello senior','Concass� de tomates, Mozzarela, Rostello, Champignons, Olives noires','18.50',true,1,'2018-08-18 07:24:25');
INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('pz.rgna.hulk','Regina Rostello hulk','Concass� de tomates, Mozzarela, Rostello, Champignons, Olives noires','20.50',true,1,'2018-08-18 07:25:42');

INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('pz.4frg.jnr','4 Fromaggi junior','Concass� de tomates, Mozzarela, Gorgonzola, Scamorza fum�e, Parmigiano','16.50',true,1,'2018-08-18 07:27:33');
INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('pz.4frg.moy','4 Fromaggi moyenne','Concass� de tomates, Mozzarela, Gorgonzola, Scamorza fum�e, Parmigiano','18.50',true,1,'2018-08-18 07:28:03');
INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('pz.4frg.sen','4 Fromaggi senior','Concass� de tomates, Mozzarela, Gorgonzola, Scamorza fum�e, Parmigiano','20.50',true,1,'2018-08-18 07:28:57');
INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('pz.4frg.hulk','4 Fromaggi hulk','Concass� de tomates, Mozzarela, Gorgonzola, Scamorza fum�e, Parmigiano','22.50',true,1,'2018-08-18 07:29:18');

INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('pz.crbnra.jnr','Carbonara junior','Cr�me fra�che, Mozzarela, Bacon, Oeuf, Parmigiano','14.50',true,1,'2018-08-18 07:33:42');
INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('pz.crbnra.moy','Carbonara moyenne','Cr�me fra�che, Mozzarela, Bacon, Oeuf, Parmigiano','16.50',true,1,'2018-08-18 07:35:17');
INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('pz.crbnra.sen','Carbonara senior','Cr�me fra�che, Mozzarela, Bacon, Oeuf, Parmigiano','18.50',true,1,'2018-08-18 07:36:35');
INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('pz.crbnra.hulk','Carbonara hulk','Cr�me fra�che, Mozzarela, Bacon, Oeuf, Parmigiano','20.50',true,1,'2018-08-18 07:38:51');

INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('pz.spe.pizz.jnr','Speciale Pizza�olo junior','Concass� de tomates, Mozzarela, Jambon, Oeuf, Cr�me fra�che, Ciboulette','15.50',true,1,'2018-08-18 07:41:12');
INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('pz.spe.pizz.moy','Speciale Pizza�olo moyenne','Concass� de tomates, Mozzarela, Jambon, Oeuf, Cr�me fra�che, Ciboulette','17.50',true,1,'2018-08-18 07:42:42');
INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('pz.spe.pizz.sen','Speciale Pizza�olo senior','Concass� de tomates, Mozzarela, Jambon, Oeuf, Cr�me fra�che, Ciboulette','19.50',true,1,'2018-08-18 07:44:36');
INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('pz.spe.pizz.hulk','Speciale Pizza�olo hulk','Concass� de tomates, Mozzarela, Jambon, Oeuf, Cr�me fra�che, Ciboulette','21.50',true,1,'2018-08-18 07:48:41');

INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('pz.veg.jnr','V�g�tarienne junior','Concass� de tomates, Mozzarela, Aubergine, Courgette, Oignon, Tomates cerises, Olives noires','14.50',true,1,'2018-08-18 07:51:03');
INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('pz.veg.moy','V�g�tarienne moyenne','Concass� de tomates, Mozzarela, Aubergine, Courgette, Oignon, Tomates cerises, Olives noires','16.50',true,1,'2018-08-18 07:51:51');
INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('pz.veg.sen','V�g�tarienne senior','Concass� de tomates, Mozzarela, Aubergine, Courgette, Oignon, Tomates cerises, Olives noires','18.50',true,1,'2018-08-18 07:52:37');
INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('pz.veg.hulk','V�g�tarienne hulk','Concass� de tomates, Mozzarela, Aubergine, Courgette, Oignon, Tomates cerises, Olives noires','20.50',true,1,'2018-08-18 07:54:07');

INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('pz.calz.Pollo.jnr','Calzone Pollo e Scamorza junior','Concass� de tomates, Cr�me fra�che, Mozzarela, Eminc�s de poulet, Scamorza fum�e','17.50',true,1,'2018-08-18 07:57:34');
INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('pz.calz.Pollo.moy','Calzone Pollo e Scamorza moyenne','Concass� de tomates, Cr�me fra�che, Mozzarela, Eminc�s de poulet, Scamorza fum�e','19.50',true,1,'2018-08-18 07:58:47');
INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('pz.calz.Pollo.sen','Calzone Pollo e Scamorza senior','Concass� de tomates, Cr�me fra�che, Mozzarela, Eminc�s de poulet, Scamorza fum�e','21.50',true,1,'2018-08-18 08:01:17');
INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('pz.calz.Pollo.hulk','Calzone Pollo e Scamorza hulk','Concass� de tomates, Cr�me fra�che, Mozzarela, Eminc�s de poulet, Scamorza fum�e','23.50',true,1,'2018-08-18 08:02:09');

INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('pz.slm.jnr','Salmone e Basilico junior','Cr�me fra�che, Mozzarela, Saumon fum�, Basilic','19.00',true,1,'2018-08-18 08:03:58');
INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('pz.slm.moy','Salmone e Basilico moyenne','Cr�me fra�che, Mozzarela, Saumon fum�, Basilic','21.00',true,1,'2018-08-18 08:04:17');
INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('pz.slm.sen','Salmone e Basilico senior','Cr�me fra�che, Mozzarela, Saumon fum�, Basilic','23.00',true,1,'2018-08-18 08:06:03');
INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('pz.slm.hulk','Salmone e Basilico hulk','Cr�me fra�che, Mozzarela, Saumon fum�, Basilic','25.00',true,1,'2018-08-18 08:07:31');

INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('bs.evian.sml','Evian','Eau de montagne - 50cl','2.00',true,2,'2018-08-19 15:08:47');
INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('bs.evian.lrg','Evian','Eau de montagne - 1,5L','3.50',true,2,'2018-08-19 15:09:36');

INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('bs.spel.sml','San Pellegrino','Eau p�tillante - 50cl ','2.50',true,2,'2018-08-19 15:10:21');
INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('bs.spel.lrg','San Pellegrino','Eau p�tillante - 1,5L','4.00',true,2,'2018-08-19 15:10:59');

INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('bs.pepsi.sml','Pepsi','Soda - 33cl','2.50',true,2,'2018-08-19 15:12:14');
INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('bs.pepsi.moy','Pepsi','Soda - 50 cl','3.00',true,2,'2018-08-19 15:13:52');
INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('bs.pepsi.btl','Pepsi','Soda - 1,5L','4.50',true,2,'2018-08-19 15:15:08');

INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('bs.fta.org.sml','Fanta orange','Soda - 33cl','2.50',true,2,'2018-08-19 15:17:59');
INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('bs.fta.org.moy','Fanta orange','Soda - 50cl','3.00',true,2,'2018-08-19 15:19:14');
INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('bs.fta.org.btl','Fanta orange','Soda - 1,5L','4.50',true,2,'2018-08-19 15:20:01');

INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('bs.7up.sml','7up','Soda - 33cl','2.50',true,2,'2018-08-19 15:21:35');
INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('bs.7up.moy','7up','Soda - 50cl','3.00',true,2,'2018-08-19 15:22:37');
INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('bs.7up.btl','7up','Soda - 1,5L','4.50',true,2,'2018-08-19 15:23:23');

INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('bs.jo.sml','Jus d''orange','Jus d''orange - 25cl','3.50',true,2,'2018-08-19 15:24:43');

INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('bs.hnk.sml','Heineken','Bi�re - 33cl','4.00',false,2,'2018-08-19 15:25:17');
INSERT INTO public.menu (reference,nom,description,prix,disponible,cree_par,date_creation) VALUES ('bs.hnk.moy','Heineken','Bi�re - 50cl','6.00',true,2,'2018-08-19 15:26:54');


--- ================================================================================
--- boisson
--- ================================================================================

INSERT INTO public.boisson (produit_id,taille) VALUES (37,3),(38,4);
INSERT INTO public.boisson (produit_id,taille) VALUES (39,3),(40,4);

INSERT INTO public.boisson (produit_id,taille) VALUES (41,2),(42,3),(43,4);
INSERT INTO public.boisson (produit_id,taille) VALUES (44,2),(45,3),(46,4);
INSERT INTO public.boisson (produit_id,taille) VALUES (47,2),(48,3),(49,4);

INSERT INTO public.boisson (produit_id,taille) VALUES (50,1);

INSERT INTO public.boisson (produit_id,taille) VALUES (51,2),(52,3);


--- ================================================================================
--- pizza
--- ================================================================================

INSERT INTO public.pizza (produit_id,taille) VALUES (1,1),(2,2),(3,3),(4,4);
INSERT INTO public.pizza (produit_id,taille) VALUES (5,1),(6,2),(7,3),(8,4);
INSERT INTO public.pizza (produit_id,taille) VALUES (9,1),(10,2),(11,3),(12,4);
INSERT INTO public.pizza (produit_id,taille) VALUES (13,1),(14,2),(15,3),(16,4);
INSERT INTO public.pizza (produit_id,taille) VALUES (17,1),(18,2),(19,3),(20,4);
INSERT INTO public.pizza (produit_id,taille) VALUES (21,1),(22,2),(23,3),(24,4);
INSERT INTO public.pizza (produit_id,taille) VALUES (25,1),(26,2),(27,3),(28,4);
INSERT INTO public.pizza (produit_id,taille) VALUES (29,1),(30,2),(31,3),(32,4);
INSERT INTO public.pizza (produit_id,taille) VALUES (33,1),(34,2),(35,3),(36,4);


--- ================================================================================
--- recette
--- ================================================================================

-- Magarita 
INSERT INTO public.recette (pizza_id,id_ingredient,quantite) VALUES (1,1,1),(1,2,1),(1,3,1),(1,4,1),  (1,5,1),(1,7,1),(1,12,1);
INSERT INTO public.recette (pizza_id,id_ingredient,quantite) VALUES (2,1,2),(2,2,2),(2,3,2),(2,4,2),  (2,5,2),(2,7,2),(2,12,2);
INSERT INTO public.recette (pizza_id,id_ingredient,quantite) VALUES (3,1,3),(3,2,3),(3,3,3),(3,4,3),  (3,5,3),(3,7,3),(3,12,3);
INSERT INTO public.recette (pizza_id,id_ingredient,quantite) VALUES (4,1,4),(4,2,4),(4,3,4),(4,4,4),  (4,5,4),(4,7,4),(4,12,4);

-- Ch�vre et Miel
INSERT INTO public.recette (pizza_id,id_ingredient,quantite) VALUES (5,1,1),(5,2,1),(5,3,1),(5,4,1),  (5,6,1),(5,29,1),(5,7,1),(5,8,1),(5,15,1),(5,13,1);
INSERT INTO public.recette (pizza_id,id_ingredient,quantite) VALUES (6,1,2),(6,2,2),(6,3,2),(6,4,2),  (6,6,2),(6,29,2),(6,7,2),(6,8,2),(6,15,2),(6,13,2);
INSERT INTO public.recette (pizza_id,id_ingredient,quantite) VALUES (7,1,3),(7,2,3),(7,3,3),(7,4,3),  (7,6,3),(7,29,3),(7,7,3),(7,8,3),(7,15,3),(7,13,3);
INSERT INTO public.recette (pizza_id,id_ingredient,quantite) VALUES (8,1,4),(8,2,4),(8,3,4),(8,4,4),  (8,6,4),(8,29,4),(8,7,4),(8,8,4),(8,15,4),(8,13,4);

-- Regina Rostello
INSERT INTO public.recette (pizza_id,id_ingredient,quantite) VALUES (9,1,1),(9,2,1),(9,3,1),(9,4,1),  (9,5,1),(9,7,1),(9,16,1),(9,22,1),(9,21,1);
INSERT INTO public.recette (pizza_id,id_ingredient,quantite) VALUES (10,1,2),(10,2,2),(10,3,2),(10,4,2),  (10,5,2),(10,7,2),(10,16,2),(10,22,2),(10,21,2);
INSERT INTO public.recette (pizza_id,id_ingredient,quantite) VALUES (11,1,3),(11,2,3),(11,3,3),(11,4,3),  (11,5,3),(11,7,3),(11,16,3),(11,22,3),(11,21,3);
INSERT INTO public.recette (pizza_id,id_ingredient,quantite) VALUES (12,1,4),(12,2,4),(12,3,4),(12,4,4),  (12,5,4),(12,7,4),(12,16,4),(12,22,4),(12,21,4);

-- 4 Fromaggi
INSERT INTO public.recette (pizza_id,id_ingredient,quantite) VALUES (13,1,1),(13,2,1),(13,3,1),(13,4,1),  (13,5,1),(13,7,1),(13,9,1),(13,10,1),(13,11,1);
INSERT INTO public.recette (pizza_id,id_ingredient,quantite) VALUES (14,1,2),(14,2,2),(14,3,2),(14,4,2),  (14,5,2),(14,7,2),(14,9,2),(14,10,2),(14,11,2);
INSERT INTO public.recette (pizza_id,id_ingredient,quantite) VALUES (15,1,3),(15,2,3),(15,3,3),(15,4,3),  (15,5,3),(15,7,3),(15,9,3),(15,10,3),(15,11,3);
INSERT INTO public.recette (pizza_id,id_ingredient,quantite) VALUES (16,1,4),(16,2,4),(16,3,4),(16,4,4),  (16,5,4),(16,7,4),(16,9,4),(16,10,4),(16,11,4);

-- Carbonara
INSERT INTO public.recette (pizza_id,id_ingredient,quantite) VALUES (17,1,1),(17,2,1),(17,3,1),(17,4,1),  (17,6,1),(17,7,1),(17,18,1),(17,28,1),(17,11,1);
INSERT INTO public.recette (pizza_id,id_ingredient,quantite) VALUES (18,1,2),(18,2,2),(18,3,2),(18,4,2),  (18,6,2),(18,7,2),(18,18,2),(18,28,2),(18,11,2);
INSERT INTO public.recette (pizza_id,id_ingredient,quantite) VALUES (19,1,3),(19,2,3),(19,3,3),(19,4,3),  (19,6,3),(19,7,3),(19,18,3),(19,28,3),(19,11,3);
INSERT INTO public.recette (pizza_id,id_ingredient,quantite) VALUES (20,1,4),(20,2,4),(20,3,4),(20,4,4),  (20,6,4),(20,7,4),(20,18,4),(20,28,4),(20,11,4);

--Speciale Pizza�olo
INSERT INTO public.recette (pizza_id,id_ingredient,quantite) VALUES (21,1,1),(21,2,1),(21,3,1),(21,4,1),  (21,5,1),(21,7,1),(21,17,1),(21,28,1),(21,6,1),(21,14,1);
INSERT INTO public.recette (pizza_id,id_ingredient,quantite) VALUES (22,1,2),(22,2,2),(22,3,2),(22,4,2),  (22,5,2),(22,7,2),(22,17,2),(22,28,2),(22,6,2),(22,14,2);
INSERT INTO public.recette (pizza_id,id_ingredient,quantite) VALUES (23,1,3),(23,2,3),(23,3,3),(23,4,3),  (23,5,3),(23,7,3),(23,17,3),(23,28,3),(23,6,3),(23,14,3);
INSERT INTO public.recette (pizza_id,id_ingredient,quantite) VALUES (24,1,4),(24,2,1),(24,3,1),(24,4,4),  (24,5,4),(24,7,4),(24,17,4),(24,28,4),(24,6,4),(24,14,4);

-- V�g�tarienne
INSERT INTO public.recette (pizza_id,id_ingredient,quantite) VALUES (25,1,1),(25,2,1),(25,3,1),(25,4,1),  (25,5,1),(25,23,1),(25,24,1),(25,25,1),(25,27,1),(25,7,1),(25,26,1),(25,21,1);
INSERT INTO public.recette (pizza_id,id_ingredient,quantite) VALUES (26,1,2),(26,2,2),(26,3,2),(26,4,2),  (26,5,2),(26,23,2),(26,24,2),(26,25,2),(26,27,2),(26,7,2),(26,26,2),(26,21,2);
INSERT INTO public.recette (pizza_id,id_ingredient,quantite) VALUES (27,1,3),(27,2,3),(27,3,3),(27,4,3),  (27,5,3),(27,23,3),(27,24,3),(27,25,3),(27,27,3),(27,7,3),(27,26,3),(27,21,3);
INSERT INTO public.recette (pizza_id,id_ingredient,quantite) VALUES (28,1,4),(28,2,4),(28,3,4),(28,4,4),  (28,5,4),(28,23,4),(28,24,4),(28,25,4),(28,27,4),(28,7,4),(28,26,4),(28,21,4);

-- Calzone Pollo e Scamorza
INSERT INTO public.recette (pizza_id,id_ingredient,quantite) VALUES (29,1,1),(29,2,1),(29,3,1),(29,4,1),  (29,5,1),(29,6,1),(29,7,1),(29,19,1),(29,10,1);
INSERT INTO public.recette (pizza_id,id_ingredient,quantite) VALUES (30,1,2),(30,2,2),(30,3,2),(30,4,2),  (30,5,2),(30,6,2),(30,7,2),(30,19,2),(30,10,2);
INSERT INTO public.recette (pizza_id,id_ingredient,quantite) VALUES (31,1,3),(31,2,3),(31,3,3),(31,4,3),  (31,5,3),(31,6,3),(31,7,3),(31,19,3),(31,10,3);
INSERT INTO public.recette (pizza_id,id_ingredient,quantite) VALUES (32,1,4),(32,2,4),(32,3,4),(32,4,4),  (32,5,4),(32,6,4),(32,7,4),(32,19,4),(32,10,4);


-- Salmone e Basilico
INSERT INTO public.recette (pizza_id,id_ingredient,quantite) VALUES (33,1,1),(33,2,1),(33,3,1),(33,4,1),  (33,6,1),(33,7,1),(33,20,1),(33,12,1);
INSERT INTO public.recette (pizza_id,id_ingredient,quantite) VALUES (34,1,2),(34,2,2),(34,3,2),(34,4,2),  (34,6,2),(34,7,2),(34,20,2),(34,12,2);
INSERT INTO public.recette (pizza_id,id_ingredient,quantite) VALUES (35,1,3),(35,2,3),(35,3,3),(35,4,3),  (35,6,3),(35,7,3),(35,20,3),(35,12,3);
INSERT INTO public.recette (pizza_id,id_ingredient,quantite) VALUES (36,1,4),(36,2,4),(36,3,4),(36,4,4),  (36,6,4),(36,7,4),(36,20,4),(36,12,4);



--- ================================================================================
--- stock_bar
--- ================================================================================

INSERT INTO public.stock_bar (id_restaurant,boisson_id,quantite) VALUES 
(1,37,58),(1,38,14),(1,39,49),(1,40,78),(1,41,62),(1,42,45),(1,43,26),(1,44,65),
(1,45,75),(1,46,196),(1,47,148),(1,48,46),(1,49,16),(1,50,124),(1,51,59),(1,52,89); 

INSERT INTO public.stock_bar (id_restaurant,boisson_id,quantite) VALUES 
(2,37,56),(2,38,196),(2,39,156),(2,40,75),(2,41,114),(2,42,163),(2,43,18),(2,44,46),
(2,45,45),(2,46,124),(2,47,89),(2,48,23),(2,49,151),(2,50,145),(2,51,46),(2,52,123); 

INSERT INTO public.stock_bar (id_restaurant,boisson_id,quantite) VALUES 
(3,37,104),(3,38,163),(3,39,75),(3,40,146),(3,41,186),(3,42,56),(3,43,196),(3,44,145),
(3,45,103),(3,46,118),(3,47,66),(3,48,144),(3,49,163),(3,50,34),(3,51,145),(3,52,163); 

INSERT INTO public.stock_bar (id_restaurant,boisson_id,quantite) VALUES 
(4,37,146),(4,38,94),(4,39,75),(4,40,118),(4,41,102),(4,42,99),(4,43,79),(4,44,77),
(4,45,176),(4,46,86),(4,47,46),(4,48,74),(4,49,176),(4,50,100),(4,51,84),(4,52,93); 

INSERT INTO public.stock_bar (id_restaurant,boisson_id,quantite) VALUES 
(5,37,45),(5,38,56),(5,39,43),(5,40,176),(5,41,161),(5,42,156),(5,43,48),(5,44,95),
(5,45,109),(5,46,73),(5,47,123),(5,48,127),(5,49,118),(5,50,153),(5,51,86),(5,52,46); 


--- ================================================================================
--- stock_cuisine
--- ================================================================================

INSERT INTO public.stock_cuisine (id_restaurant,id_ingredient,quantite) VALUES 
(1,1,205),(1,2,248),(1,3,231),(1,4,146),(1,5,248),(1,6,115),(1,7,62),(1,8,178),(1,9,99),(1,10,145),(1,11,185),(1,12,113),
(1,13,263),(1,14,146),(1,15,96),(1,16,141),(1,17,452),(1,18,234),(1,19,100),(1,20,57),(1,21,86),(1,22,204),(1,23,56),(1,24,76),
(1,25,156),(1,26,196),(1,27,77),(1,28,175),(1,29,635);

INSERT INTO public.stock_cuisine (id_restaurant,id_ingredient,quantite) VALUES 
(2,1,145),(2,2,186),(2,3,75),(2,4,116),(2,5,153),(2,6,102),(2,7,106),(2,8,156),(2,9,116),(2,10,76),(2,11,146),(2,12,209),
(2,13,146),(2,14,235),(2,15,256),(2,16,56),(2,17,245),(2,18,75),(2,19,65),(2,20,39),(2,21,46),(2,22,76),(2,23,64),(2,24,156),
(2,25,146),(2,26,175),(2,27,163),(2,28,107),(2,29,79);

INSERT INTO public.stock_cuisine (id_restaurant,id_ingredient,quantite) VALUES 
(3,1,102),(3,2,140),(3,3,146),(3,4,118),(3,5,186),(3,6,112),(3,7,70),(3,8,138),(3,9,170),(3,10,110),(3,11,200),(3,12,240),
(3,13,296),(3,14,176),(3,15,169),(3,16,234),(3,17,146),(3,18,134),(3,19,86),(3,20,146),(3,21,160),(3,22,100),(3,23,176),(3,24,134),
(3,25,146),(3,26,176),(3,27,119),(3,28,76),(3,29,86);

INSERT INTO public.stock_cuisine (id_restaurant,id_ingredient,quantite) VALUES 
(4,1,53),(4,2,176),(4,3,280),(4,4,270),(4,5,180),(4,6,176),(4,7,116),(4,8,186),(4,9,146),(4,10,176),(4,11,136),(4,12,176),
(4,13,100),(4,14,265),(4,15,246),(4,16,168),(4,17,186),(4,18,139),(4,19,140),(4,20,269),(4,21,275),(4,22,165),(4,23,76),(4,24,119),
(4,25,176),(4,26,148),(4,27,86),(4,28,143),(4,29,76);

INSERT INTO public.stock_cuisine (id_restaurant,id_ingredient,quantite) VALUES 
(5,1,76),(5,2,49),(5,3,101),(5,4,256),(5,5,263),(5,6,87),(5,7,178),(5,8,86),(5,9,94),(5,10,49),(5,11,136),(5,12,186),
(5,13,115),(5,14,93),(5,15,109),(5,16,178),(5,17,146),(5,18,116),(5,19,176),(5,20,207),(5,21,79),(5,22,126),(5,23,116),(5,24,168),
(5,25,176),(5,26,99),(5,27,117),(5,28,116),(5,29,196);


--- ================================================================================
--- adresse_compte_utilisateur
--- ================================================================================

SELECT setval('public.adresse_compte_utilisateur_id_seq', 1, false); 

INSERT INTO public.adresse_compte_utilisateur (numero, rue,ville,code_postal) VALUES (55,'avenue Philippe-Auguste','Paris','75011');
INSERT INTO public.adresse_compte_utilisateur (numero, rue,ville,code_postal) VALUES (22,'avenue de Saint-Mand�','Paris','75012');
INSERT INTO public.adresse_compte_utilisateur (numero, rue,ville,code_postal) VALUES (35,'rue des Meuniers','Paris','75012');
INSERT INTO public.adresse_compte_utilisateur (numero, rue,ville,code_postal) VALUES (12,'rue Breguet','Paris','75011');
INSERT INTO public.adresse_compte_utilisateur (numero, rue,ville,code_postal) VALUES (47,'rue Volta','Paris','75003');
INSERT INTO public.adresse_compte_utilisateur (numero, rue,ville,code_postal) VALUES (44,'rue de Bretagne','Paris','75003');
INSERT INTO public.adresse_compte_utilisateur (numero, rue,ville,code_postal) VALUES (2,'rue de la Roquette','Paris','75011');
INSERT INTO public.adresse_compte_utilisateur (numero, rue,ville,code_postal) VALUES (12,'rue de la Chine','Paris','75020');
INSERT INTO public.adresse_compte_utilisateur (numero, rue,ville,code_postal) VALUES (18,'rue Boyer','Paris','75020');
INSERT INTO public.adresse_compte_utilisateur (numero, rue,ville,code_postal) VALUES (5,'rue Duranti','Paris','75011');


--- ================================================================================
--- compte_utilisateur
--- ================================================================================

SELECT setval('public.compte_utilisateur_id_seq', 1, false);

INSERT INTO public.compte_utilisateur (identifiant,mot_de_passe,prenom,nom,adresse_compte_utilisateur_id,numero_telephone,adresse_email) VALUES ('g.mansoif','mdp01','G�rard','Mansoif',1,0612322521,'g.mansoif@gmail.com');
INSERT INTO public.compte_utilisateur (identifiant,mot_de_passe,prenom,nom,adresse_compte_utilisateur_id,numero_telephone,adresse_email) VALUES ('c.heloire','mdp02','Carmen','H�loire',2,0612356345,'carmen.he@free.com');
INSERT INTO public.compte_utilisateur (identifiant,mot_de_passe,prenom,nom,adresse_compte_utilisateur_id,numero_telephone,adresse_email) VALUES ('p.igone','mdp03','Paul','Igone',3,0615326548,'paul.igone@trade.fr');
INSERT INTO public.compte_utilisateur (identifiant,mot_de_passe,prenom,nom,adresse_compte_utilisateur_id,numero_telephone,adresse_email) VALUES ('s.lakrep','mdp04','Suzette','Lakrep',4,0614263524,'s.lkrp@gmail.com');
INSERT INTO public.compte_utilisateur (identifiant,mot_de_passe,prenom,nom,adresse_compte_utilisateur_id,numero_telephone,adresse_email) VALUES ('t.jamain','mdp05','Th�o','Jasmain',5,0656325468,'teoj@kousmi.com');
INSERT INTO public.compte_utilisateur (identifiant,mot_de_passe,prenom,nom,adresse_compte_utilisateur_id,numero_telephone,adresse_email) VALUES ('f.oposte','mdp06','Fidel','Oposte',6,0636325452,'fideloposte@orange.fr');
INSERT INTO public.compte_utilisateur (identifiant,mot_de_passe,prenom,nom,adresse_compte_utilisateur_id,numero_telephone,adresse_email) VALUES ('d.hinault','mdp07','Dom','Hinault',7,0622365699,'domino@gmail.com');
INSERT INTO public.compte_utilisateur (identifiant,mot_de_passe,prenom,nom,adresse_compte_utilisateur_id,numero_telephone,adresse_email) VALUES ('d.Scott','mdp08','Debie','Scott',8,0675652555,'dbst@rsdk.com');
INSERT INTO public.compte_utilisateur (identifiant,mot_de_passe,prenom,nom,adresse_compte_utilisateur_id,numero_telephone,adresse_email) VALUES ('e.hochet','mdp09','Eric','Hochet',9,0678565254,'e.hochet@hotmail.com');
INSERT INTO public.compte_utilisateur (identifiant,mot_de_passe,prenom,nom,adresse_compte_utilisateur_id,numero_telephone,adresse_email) VALUES ('m.Angraive','mdp10','M�lusine','Angraive',10,0632321414,'m.angraive@fvbn.com');


--- ================================================================================
--- adresse_livraison
--- ================================================================================

SELECT setval('public.adresse_livraison_id_seq', 1, false); 

INSERT INTO public.adresse_livraison (numero, rue,ville,code_postal) VALUES (48,'rue du Saint-Bernard','Paris','75011');
INSERT INTO public.adresse_livraison (numero, rue,ville,code_postal) VALUES (55,'avenue Philippe-Auguste','Paris','75011');
INSERT INTO public.adresse_livraison (numero, rue,ville,code_postal) VALUES (22,'avenue de Saint-Mand�','Paris','75012');
INSERT INTO public.adresse_livraison (numero, rue,ville,code_postal) VALUES (66,'rue P�tion','Paris','75011');
INSERT INTO public.adresse_livraison (numero, rue,ville,code_postal) VALUES (35,'rue des Meuniers','Paris','75012');
INSERT INTO public.adresse_livraison (numero, rue,ville,code_postal) VALUES (12,'rue Breguet','Paris','75011');
INSERT INTO public.adresse_livraison (numero, rue,ville,code_postal) VALUES (47,'rue Volta','Paris','75003');
INSERT INTO public.adresse_livraison (numero, rue,ville,code_postal) VALUES (44,'rue de Bretagne','Paris','75003');
INSERT INTO public.adresse_livraison (numero, rue,ville,code_postal) VALUES (2,'rue de la Roquette','Paris','75011');
INSERT INTO public.adresse_livraison (numero, rue,ville,code_postal) VALUES (12,'rue de la Chine','Paris','75020');
INSERT INTO public.adresse_livraison (numero, rue,ville,code_postal) VALUES (18,'rue Boyer','Paris','75020');
INSERT INTO public.adresse_livraison (numero, rue,ville,code_postal) VALUES (73,'rue Emilio Castelar','Paris','75011');
INSERT INTO public.adresse_livraison (numero, rue,ville,code_postal) VALUES (5,'rue Duranti','Paris','75011');




--- ================================================================================
--- coordonnes_livraison
--- ================================================================================

SELECT setval('public.coordonnees_livraison_id_seq', 1, false); 

INSERT INTO public.coordonnees_livraison (nom,prenom,adresse_livraison_id,numero_telephone,adresse_email) VALUES ('Paul','Dubois',1,06325232,'p.dubois@gmail.com');
INSERT INTO public.coordonnees_livraison (nom,prenom,adresse_livraison_id,numero_telephone,adresse_email) VALUES ('G�rard','Mansoif',2,0612322521,'g.mansoif@gmail.com');
INSERT INTO public.coordonnees_livraison (nom,prenom,adresse_livraison_id,numero_telephone,adresse_email) VALUES ('Carmen','H�loire',3,0612356345,'carmen.he@free.com');
INSERT INTO public.coordonnees_livraison (nom,prenom,adresse_livraison_id,numero_telephone,adresse_email) VALUES ('Louis','Branchant',4,0612322521,'l.branchant@gmail.com');
INSERT INTO public.coordonnees_livraison (nom,prenom,adresse_livraison_id,numero_telephone,adresse_email) VALUES ('Paul','Igone',5,0615326548,'paul.igone@trade.fr');
INSERT INTO public.coordonnees_livraison (nom,prenom,adresse_livraison_id,numero_telephone,adresse_email) VALUES ('Suzette','Lakrep',6,0614263524,'s.lkrp@gmail.com');
INSERT INTO public.coordonnees_livraison (nom,prenom,adresse_livraison_id,numero_telephone,adresse_email) VALUES ('Th�o','Jasmain',7,0656325468,'teoj@kousmi.com');
INSERT INTO public.coordonnees_livraison (nom,prenom,adresse_livraison_id,numero_telephone,adresse_email) VALUES ('Fidel','Oposte',8,0636325452,'fideloposte@orange.fr');
INSERT INTO public.coordonnees_livraison (nom,prenom,adresse_livraison_id,numero_telephone,adresse_email) VALUES ('Dom','Hinault',9,0622365699,'domino@gmail.com');
INSERT INTO public.coordonnees_livraison (nom,prenom,adresse_livraison_id,numero_telephone,adresse_email) VALUES ('Debie','Scott',10,0675652555,'dbst@rsdk.com');
INSERT INTO public.coordonnees_livraison (nom,prenom,adresse_livraison_id,numero_telephone,adresse_email) VALUES ('Eric','Hochet',11,0678565254,'e.hochet@hotmail.com');
INSERT INTO public.coordonnees_livraison (nom,prenom,adresse_livraison_id,numero_telephone,adresse_email) VALUES ('Fabien','Tault',12,0612146325,'f.tault@jihd.com');
INSERT INTO public.coordonnees_livraison (nom,prenom,adresse_livraison_id,numero_telephone,adresse_email) VALUES ('M�lusine','Angraive',13,0632321414,'m.angraive@fvbn.com');


--- ================================================================================
--- mode_reglement
--- ================================================================================

SELECT setval('public.mode_reglement_id_seq', 1, false); 

INSERT INTO public.mode_reglement (type) VALUES ('Carte bancaire'), ('Esp�ces'), ('Ch�que'), ('Ticket(s) restaurant'), ('Ch�que(s) vacances');


--- ================================================================================
--- etat_commande
--- ================================================================================

SELECT setval('public.etat_commande_id_seq', 1, false);

INSERT INTO public.etat_commande (etat) VALUES ('En attente de pr�paration'),('En pr�paration'),('En attente de livraison'),('En livraison'),('Achemin�e'),('Annul�e');


--- ================================================================================
--- commande
--- ================================================================================

SELECT setval('public.commande_id_seq', 1, false); 

INSERT INTO public.commande (reference_commande,date_creation,coordonnees_livraison_id,mode_reglement,etat_commande,restaurant_id,hotesse_id,regle) VALUES ('a23cde78','2018-08-27 11:45:42',1,3,5,1,3,true);
INSERT INTO public.commande (reference_commande,date_creation,coordonnees_livraison_id,mode_reglement,etat_commande,restaurant_id,hotesse_id,regle) VALUES ('a2cedz45','2018-08-27 11:56:42',4,2,6,5,7,true);
INSERT INTO public.commande (reference_commande,date_creation,coordonnees_livraison_id,mode_reglement,etat_commande,restaurant_id,hotesse_id,regle) VALUES ('a23dze25','2018-08-27 12:45:42',12,1,5,4,2,false);
INSERT INTO public.commande (reference_commande,date_creation,compte_utilisateur_id,coordonnees_livraison_id,mode_reglement,etat_commande,restaurant_id,livreur_id,regle) VALUES ('a23cdf47','2018-08-28 21:21:42',1,1,5,5,1,8,true);
INSERT INTO public.commande (reference_commande,date_creation,compte_utilisateur_id,coordonnees_livraison_id,mode_reglement,etat_commande,restaurant_id,livreur_id,regle) VALUES ('a23cdda4','2018-08-28 22:25:17',2,4,5,4,3,11,false);
INSERT INTO public.commande (reference_commande,date_creation,compte_utilisateur_id,coordonnees_livraison_id,mode_reglement,etat_commande,restaurant_id,livreur_id,regle) VALUES ('a23cvzv4','2018-08-28 22:23:52',3,2,1,5,4,9,true);
INSERT INTO public.commande (reference_commande,date_creation,compte_utilisateur_id,coordonnees_livraison_id,mode_reglement,etat_commande,restaurant_id,livreur_id,regle) VALUES ('a23cde47','2018-08-28 20:16:23',4,2,4,6,5,10,false);
INSERT INTO public.commande (reference_commande,date_creation,compte_utilisateur_id,coordonnees_livraison_id,mode_reglement,etat_commande,restaurant_id,livreur_id,regle) VALUES ('a2cezc02','2018-08-28 18:21:44',5,5,3,4,2,10,true);
INSERT INTO public.commande (reference_commande,date_creation,compte_utilisateur_id,coordonnees_livraison_id,mode_reglement,etat_commande,restaurant_id,livreur_id,regle) VALUES ('a2cvrz07','2018-08-28 21:14:26',6,2,3,2,2,11,true);
INSERT INTO public.commande (reference_commande,date_creation,compte_utilisateur_id,coordonnees_livraison_id,mode_reglement,etat_commande,restaurant_id,livreur_id,regle) VALUES ('a23cvzv2','2018-08-28 19:59:42',7,1,2,6,1,11,false);
INSERT INTO public.commande (reference_commande,date_creation,compte_utilisateur_id,coordonnees_livraison_id,mode_reglement,etat_commande,restaurant_id,livreur_id,regle) VALUES ('a23vz240','2018-08-28 19:46:30',8,2,2,2,4,9,false);
INSERT INTO public.commande (reference_commande,date_creation,compte_utilisateur_id,coordonnees_livraison_id,mode_reglement,etat_commande,restaurant_id,livreur_id,regle) VALUES ('a23cez45','2018-08-28 21:56:03',9,2,1,1,3,8,true);
INSERT INTO public.commande (reference_commande,date_creation,compte_utilisateur_id,coordonnees_livraison_id,mode_reglement,etat_commande,restaurant_id,livreur_id,regle) VALUES ('a23fea24','2018-08-28 21:04:17',10,3,4,4,5,9,false);





--- ================================================================================
--- panier
--- ================================================================================

INSERT INTO public.panier (id_commande,produit_id,quantite) VALUES (1,12,1),(1,37,1),(1,14,1),(1,50,1);
INSERT INTO public.panier (id_commande,produit_id,quantite) VALUES (2,17,2),(2,6,2);
INSERT INTO public.panier (id_commande,produit_id,quantite) VALUES (3,36,1),(3,34,1),(3,50,2);
INSERT INTO public.panier (id_commande,produit_id,quantite) VALUES (4,33,1),(4,27,1),(4,39,1),(4,40,1);
INSERT INTO public.panier (id_commande,produit_id,quantite) VALUES (5,7,1),(5,9,1),(5,13,1),(5,50,3);
INSERT INTO public.panier (id_commande,produit_id,quantite) VALUES (6,2,3),(6,3,2),(6,49,6);
INSERT INTO public.panier (id_commande,produit_id,quantite) VALUES (7,31,1),(7,29,1),(7,52,1),(7,41,1);
INSERT INTO public.panier (id_commande,produit_id,quantite) VALUES (8,2,1),(8,52,1);
INSERT INTO public.panier (id_commande,produit_id,quantite) VALUES (9,7,2),(9,37,2);
INSERT INTO public.panier (id_commande,produit_id,quantite) VALUES (10,11,3),(10,17,1),(10,50,4);
INSERT INTO public.panier (id_commande,produit_id,quantite) VALUES (11,19,1),(11,39,1);
INSERT INTO public.panier (id_commande,produit_id,quantite) VALUES (12,21,1),(12,40,1);
INSERT INTO public.panier (id_commande,produit_id,quantite) VALUES (13,30,1),(13,44,1);



COMMIT;












